import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { RecoilRoot, useRecoilValue } from 'recoil';
import DataGrid from './DataGrid';
import * as tradeEventAtoms from '../state/tradeEventAtoms';

// Mock recoil state and hooks
jest.mock('recoil', () => ({
  ...jest.requireActual('recoil'),
  useRecoilValue: jest.fn(),
}));

jest.mock('../state/tradeEventAtoms', () => ({
  ...jest.requireActual('../state/tradeEventAtoms'),
  useLoadTradeEvents: jest.fn(),
}));

describe('DataGrid Component', () => {
  const mockLoadTradeEvents = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
    (tradeEventAtoms.useLoadTradeEvents as jest.Mock).mockImplementation(() => mockLoadTradeEvents);
  });

  it('renders the DataGrid component', () => {
    (useRecoilValue as jest.Mock).mockImplementation((atom: any) => {
      if (atom === tradeEventAtoms.tradeEventsState) return [];
      if (atom === tradeEventAtoms.tradeEventsLoadingState) return false;
      if (atom === tradeEventAtoms.tradeEventsErrorState) return null;
    });

    render(
      <RecoilRoot>
        <DataGrid />
      </RecoilRoot>
    );

    expect(screen.getByText('Trade Events')).toBeInTheDocument();
    expect(screen.getByText('Refresh')).toBeInTheDocument();
  });

  it('shows a loading indicator when loading', () => {
    (useRecoilValue as jest.Mock).mockImplementation((atom: any) => {
      if (atom === tradeEventAtoms.tradeEventsState) return [];
      if (atom === tradeEventAtoms.tradeEventsLoadingState) return true;
      if (atom === tradeEventAtoms.tradeEventsErrorState) return null;
    });

    render(
      <RecoilRoot>
        <DataGrid />
      </RecoilRoot>
    );

    expect(screen.getByText('Loading trade events...')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /loading/i })).toBeDisabled();
  });

  it('displays an error message when there is an error', () => {
    (useRecoilValue as jest.Mock).mockImplementation((atom: any) => {
      if (atom === tradeEventAtoms.tradeEventsState) return [];
      if (atom === tradeEventAtoms.tradeEventsLoadingState) return false;
      if (atom === tradeEventAtoms.tradeEventsErrorState) return 'Failed to load data';
    });

    render(
      <RecoilRoot>
        <DataGrid />
      </RecoilRoot>
    );

    expect(screen.getByText('Error Loading Trade Events')).toBeInTheDocument();
    expect(screen.getByText('Failed to load data')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /try again/i })).toBeInTheDocument();
  });

  it('renders trade events data when available', () => {
    const mockEvents = [
      { id: 1, name: 'Event 1', type: 'Type A', symbol: 'SYM1', date: '2023-01-01' },
      { id: 2, name: 'Event 2', type: 'Type B', symbol: 'SYM2', date: '2023-01-02' },
    ];
    (useRecoilValue as jest.Mock).mockImplementation((atom: any) => {
      if (atom === tradeEventAtoms.tradeEventsState) return mockEvents;
      if (atom === tradeEventAtoms.tradeEventsLoadingState) return false;
      if (atom === tradeEventAtoms.tradeEventsErrorState) return null;
    });

    render(
      <RecoilRoot>
        <DataGrid />
      </RecoilRoot>
    );

    expect(screen.getByText('Event 1')).toBeInTheDocument();
    expect(screen.getByText('Event 2')).toBeInTheDocument();
    expect(screen.queryByText('Event 3')).not.toBeInTheDocument();
  });

  it('calls the refresh function when the refresh button is clicked', () => {
    (useRecoilValue as jest.Mock).mockImplementation((atom: any) => {
      if (atom === tradeEventAtoms.tradeEventsState) return [];
      if (atom === tradeEventAtoms.tradeEventsLoadingState) return false;
      if (atom === tradeEventAtoms.tradeEventsErrorState) return null;
    });

    render(
      <RecoilRoot>
        <DataGrid />
      </RecoilRoot>
    );

    const refreshButton = screen.getByRole('button', { name: /refresh/i });
    fireEvent.click(refreshButton);

    expect(mockLoadTradeEvents).toHaveBeenCalledTimes(1);
  });

  it('displays a message when no trade events are available', () => {
    (useRecoilValue as jest.Mock).mockImplementation((atom: any) => {
      if (atom === tradeEventAtoms.tradeEventsState) return [];
      if (atom === tradeEventAtoms.tradeEventsLoadingState) return false;
      if (atom === tradeEventAtoms.tradeEventsErrorState) return null;
    });

    render(
      <RecoilRoot>
        <DataGrid />
      </RecoilRoot>
    );

    expect(screen.getByText('No trade events data available')).toBeInTheDocument();
  });
});
