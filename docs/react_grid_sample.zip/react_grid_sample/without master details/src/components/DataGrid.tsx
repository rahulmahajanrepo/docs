import React, { useMemo, useEffect, useState, useRef, useCallback } from 'react';
import { AgGridReact } from 'ag-grid-react';
import { ColDef, ModuleRegistry, AllCommunityModule, GridReadyEvent, FirstDataRenderedEvent } from 'ag-grid-community';
import { TradeEvent, tradeEventsErrorState, tradeEventsLoadingState, tradeEventsState, useLoadTradeEvents } from '../state/tradeEventAtoms';
import ActionLinksRenderer from './ActionLinksRenderer';

// Import AG Grid styles
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { useRecoilValue } from 'recoil';

// Register AG Grid modules
ModuleRegistry.registerModules([AllCommunityModule]);

const DataGrid: React.FC = () => {
  const loadEvents = useLoadTradeEvents(true); // auto-load once on mount
  const events = useRecoilValue(tradeEventsState);
  const isLoading = useRecoilValue(tradeEventsLoadingState);
  const error = useRecoilValue(tradeEventsErrorState);

  // Debug - log when events change
  useEffect(() => {
    console.log('Trade events data:', events);
  }, [events]);

  const columnDefs = useMemo<ColDef<TradeEvent>[]>(() => [
    { field: 'name', headerName: 'Name', sortable: true, filter: true },
    { field: 'type', headerName: 'Type', sortable: true, filter: true },
    { field: 'symbol', headerName: 'Symbol', sortable: true, filter: true },
    { field: 'date', headerName: 'Date', sortable: true, filter: true },
    { field: 'id', headerName: 'ID', sortable: true, filter: true },
    { 
      field: 'actionLinks', 
      headerName: 'Actions', 
      cellRenderer: ActionLinksRenderer,
      sortable: false,
      filter: false,
      minWidth: 200
    }
  ], []);

  const defaultColDef = useMemo<ColDef>(() => ({
    flex: 1,
    minWidth: 100,
    resizable: true,
  }), []);

  const handleRefresh = useCallback(() => {
    loadEvents();
  }, [loadEvents]);

  // Create ref for grid container
  const gridContainerRef = useRef<HTMLDivElement>(null);

  // State to track container height
  const [gridHeight, setGridHeight] = useState(500);

  // Update container height when component mounts or window resizes
  useEffect(() => {
    const updateGridHeight = () => {
      if (gridContainerRef.current) {
        // Force explicit pixel height
        setGridHeight(gridContainerRef.current.clientHeight || 500);
      }
    };

    // Call once on mount
    updateGridHeight();

    // Set up resize listener
    window.addEventListener('resize', updateGridHeight);
    return () => window.removeEventListener('resize', updateGridHeight);
  }, []);

  // Memoized handlers for grid events
  const onGridReady = useCallback((params: GridReadyEvent) => {
    console.log('Grid is ready, height:', gridHeight);
    // Force grid size refresh
    params.api.sizeColumnsToFit();
    // Force refreshing the layout
    setTimeout(() => {
      params.api.redrawRows();
      params.api.sizeColumnsToFit();
    }, 100);
  }, [gridHeight]);

  const onFirstDataRendered = useCallback((params: FirstDataRenderedEvent) => {
    console.log('First data rendered');
    params.api.sizeColumnsToFit();
  }, []);

  // Memoized container style
  const containerStyle = useMemo(() => ({ 
    height: `${gridHeight}px`, 
    width: '100%' 
  }), [gridHeight]);

  // Memoized grid container style
  const gridContainerStyle = useMemo(() => ({ 
    width: '100%',
    height: 'calc(100% - 60px)', /* Explicit calculation */
    minHeight: '500px'
  }), []);

  if (error) {
    return (
      <div className="card error-card">
        <h2>Error Loading Trade Events</h2>
        <p>{error}</p>
        <button onClick={handleRefresh}>Try Again</button>
      </div>
    );
  }

  return (
    <div className="card">
      <div className="grid-header">
        <h2>Trade Events</h2>
        <button onClick={handleRefresh} disabled={isLoading}>
          {isLoading ? 'Loading...' : 'Refresh'}
        </button>
      </div>
      {isLoading && <div className="loading-indicator">Loading trade events...</div>}
      
      {/* Grid container with ref */}
      <div 
        ref={gridContainerRef}
        className="ag-theme-alpine grid-container" 
        style={gridContainerStyle}
      >
        {events.length === 0 && !isLoading && <div>No trade events data available</div>}
        <AgGridReact
          rowData={events}
          columnDefs={columnDefs}
          defaultColDef={defaultColDef}
          animateRows={true}
          rowHeight={31}
          
          // Use memoized container style
          containerStyle={containerStyle}
          
          // Ensure proper dimensions
          domLayout="normal"
          
          // Additional properties for better behavior
          suppressAutoSize={true}
          popupParent={document.body}
          suppressScrollOnNewData={true}
          
          onGridReady={onGridReady}
          onFirstDataRendered={onFirstDataRendered}
        />
      </div>
    </div>
  );
};

export default DataGrid;
