import { atom, selector, useSetRecoilState, useRecoilValue } from 'recoil';
import { fetchTradeEvents } from '../api/tradeEventsApi';
import { useEffect, useRef, useCallback } from 'react';

export interface ActionLinks {
  [key: string]: string;
}

export interface TradeEvent {
  id: string;
  name: string;
  type: string;
  symbol: string;
  date: string;
  actionLinks: ActionLinks;
}

// Loading state
export const tradeEventsLoadingState = atom<boolean>({
  key: 'tradeEventsLoadingState',
  default: false,
});

// Error state
export const tradeEventsErrorState = atom<string | null>({
  key: 'tradeEventsErrorState',
  default: null,
});

// Default state - empty array
export const tradeEventsState = atom<TradeEvent[]>({
  key: 'tradeEventsState',
  default: [],
});

// Selector that ONLY reads the events data (doesn't fetch)
export const tradeEventsQuery = selector({
  key: 'tradeEventsQuery',
  get: ({ get }) => {
    return get(tradeEventsState);
  }
});

// State to track the currently expanded row (by TradeEvent ID)
export const expandedRowState = atom<string | null>({
  key: 'expandedRowState',
  default: null,
});

// State to track the height of the expanded view
export const expandedRowHeightState = atom<number>({
  key: 'expandedRowHeightState',
  default: 300, // Default height in pixels
});

/**
 * Custom hook that handles loading trade events data.
 * 
 * @param loadOnMount If true, automatically loads data when component mounts (once)
 * @returns A function that can be called to manually load/refresh the data
 */
export const useLoadTradeEvents = (loadOnMount = false) => {
  const setEvents = useSetRecoilState(tradeEventsState);
  const setLoading = useSetRecoilState(tradeEventsLoadingState);
  const setError = useSetRecoilState(tradeEventsErrorState);
  
  // This ref prevents duplicate data fetching when components re-render
  // It ensures the automatic loading happens exactly once when loadOnMount is true
  // Unlike state variables, changing this ref doesn't trigger re-renders
  const initialLoadCompleted = useRef(false);

  // useCallback is critical here for three main reasons:
  // 1. It creates a memoized function with a stable reference that can be safely returned from the hook
  //    Without this, consumers of the hook would get a new function reference on every render
  // 2. useEffect cannot return a function to be used elsewhere - it's for running side effects only
  //    So we need a separate function definition that both useEffect and external components can access
  // 3. This same function needs to be callable from external components AND from the useEffect below
  //    A stable reference prevents the useEffect from re-running when nothing has actually changed
  const loadEvents = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      
      const events = await fetchTradeEvents();
      setEvents(events);
      
      return events;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to fetch trade events';
      setError(errorMessage);
      return [];
    } finally {
      setLoading(false);
    }
  }, [setEvents, setLoading, setError]);

  // Side effect for (automatic loading), on component mount when loadOnMount is true (but only once)
  // Without this ref check, ANY of these re-render scenarios would trigger 
  // another API call if loadOnMount is true:
  // 1. Parent component re-renders
  // 2. State changes elsewhere in the component
  // 3. Other props changing
  // 4. Context updates
  // 5. Related Recoil state changes
  useEffect(() => {
    if (loadOnMount && !initialLoadCompleted.current) {
      // Mark loading as completed so we don't fetch again on re-renders
      initialLoadCompleted.current = true;
      loadEvents();
    }
  }, [loadOnMount, loadEvents]);

  return loadEvents;
};
