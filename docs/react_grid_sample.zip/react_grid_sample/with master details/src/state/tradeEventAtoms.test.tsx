import React from 'react';
import { renderHook, act } from '@testing-library/react';
import { RecoilRoot, useRecoilValue } from 'recoil';
import { useLoadTradeEvents, tradeEventsState, tradeEventsLoadingState, tradeEventsErrorState, TradeEvent } from './tradeEventAtoms';
import { fetchTradeEvents } from '../api/tradeEventsApi';
import { describe, beforeEach, test, expect } from '@jest/globals';

// Mock the API function
import { jest } from '@jest/globals';

jest.mock('../api/tradeEventsApi');
const mockedFetchTradeEvents = fetchTradeEvents as jest.MockedFunction<typeof fetchTradeEvents>;

// Test wrapper with RecoilRoot
const wrapper = ({ children }: { children: React.ReactNode }) => (
  <RecoilRoot>{children}</RecoilRoot>
);

describe('useLoadTradeEvents', () => {
  beforeEach(() => {
    // Clear all mocks before each test
    jest.clearAllMocks();
  });

  test('should load trade events when loadOnMount is true', async () => {
    // Mock data
    const mockEvents: TradeEvent[] = [
      { 
        id: '1', 
        name: 'Event 1', 
        type: 'Trade', 
        symbol: 'AAPL', 
        date: '2023-01-01',
        actionLinks: { view: '/trade/1' }
      }
    ];
    
    // Setup the mock to return our test data
    mockedFetchTradeEvents.mockResolvedValueOnce(mockEvents);
    
    // Create a test hook that exposes all relevant state
    const useTestHook = () => {
      const loadEvents = useLoadTradeEvents(true); // loadOnMount = true
      const events = useRecoilValue(tradeEventsState);
      const loading = useRecoilValue(tradeEventsLoadingState);
      const error = useRecoilValue(tradeEventsErrorState);
      
      return { loadEvents, events, loading, error };
    };
    
    // Render the hook with our wrapper
    const { result } = renderHook(() => useTestHook(), { wrapper });
    
    // Wait for the async operation to complete
    await act(async () => {
      // Wait for any pending state updates
      await new Promise(resolve => setTimeout(resolve, 0));
    });
    
    // Verify the final state
    expect(result.current.loading).toBe(false);
    expect(result.current.events).toEqual(mockEvents);
    expect(result.current.error).toBeNull();
    expect(mockedFetchTradeEvents).toHaveBeenCalledTimes(1);
  });

  test('should not load trade events when loadOnMount is false', () => {
    // Create a hook with loadOnMount = false
    const useTestHook = () => {
      const loadEvents = useLoadTradeEvents(false);
      return { loadEvents };
    };
    
    // Render the hook
    renderHook(() => useTestHook(), { wrapper });
    
    // API should not have been called
    expect(mockedFetchTradeEvents).not.toHaveBeenCalled();
  });

  test('should manually load trade events when calling the returned function', async () => {
    // Mock data
    const mockEvents: TradeEvent[] = [
      { 
        id: '2', 
        name: 'Event 2', 
        type: 'Trade', 
        symbol: 'TSLA', 
        date: '2023-02-01',
        actionLinks: { view: '/trade/2' }
      }
    ];
    
    // Setup the mock
    mockedFetchTradeEvents.mockResolvedValueOnce(mockEvents);
    
    // Create a test hook
    const useTestHook = () => {
      const loadEvents = useLoadTradeEvents(false);
      const events = useRecoilValue(tradeEventsState);
      const loading = useRecoilValue(tradeEventsLoadingState);
      
      return { loadEvents, events, loading };
    };
    
    // Render the hook
    const { result } = renderHook(() => useTestHook(), { wrapper });
    
    // Manually call loadEvents
    await act(async () => {
      await result.current.loadEvents();
    });
    
    // Verify the state after loading
    expect(result.current.events).toEqual(mockEvents);
    expect(result.current.loading).toBe(false);
    expect(mockedFetchTradeEvents).toHaveBeenCalledTimes(1);
  });

  test('should handle API errors correctly', async () => {
    // Setup the mock to throw an error
    const errorMessage = 'API Error';
    mockedFetchTradeEvents.mockRejectedValueOnce(new Error(errorMessage));
    
    // Create a test hook
    const useTestHook = () => {
      const loadEvents = useLoadTradeEvents(true);
      const events = useRecoilValue(tradeEventsState);
      const loading = useRecoilValue(tradeEventsLoadingState);
      const error = useRecoilValue(tradeEventsErrorState);
      
      return { loadEvents, events, loading, error };
    };
    
    // Render the hook
    const { result } = renderHook(() => useTestHook(), { wrapper });
    
    // Wait for the async operation to complete
    await act(async () => {
      // Wait for any pending state updates
      await new Promise(resolve => setTimeout(resolve, 0));
    });
    
    // Verify error state
    expect(result.current.loading).toBe(false);
    expect(result.current.events).toEqual([]);
    expect(result.current.error).toBe(errorMessage);
    expect(mockedFetchTradeEvents).toHaveBeenCalledTimes(1);
  });

  test('should return events from the loadEvents function', async () => {
    // Mock data
    const mockEvents: TradeEvent[] = [
      { 
        id: '3', 
        name: 'Event 3', 
        type: 'Trade', 
        symbol: 'MSFT', 
        date: '2023-03-01',
        actionLinks: { view: '/trade/3' }
      }
    ];
    
    // Setup the mock
    mockedFetchTradeEvents.mockResolvedValueOnce(mockEvents);
    
    // Create a test hook
    const useTestHook = () => {
      const loadEvents = useLoadTradeEvents(false);
      return { loadEvents };
    };
    
    // Render the hook
    const { result } = renderHook(() => useTestHook(), { wrapper });
    
    // Call loadEvents and capture return value
    let returnedEvents;
    await act(async () => {
      returnedEvents = await result.current.loadEvents();
    });
    
    // Verify the return value
    expect(returnedEvents).toEqual(mockEvents);
  });
});
