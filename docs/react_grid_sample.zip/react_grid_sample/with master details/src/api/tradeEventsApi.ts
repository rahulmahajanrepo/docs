import axios from 'axios';
import { TradeEvent } from '../state/tradeEventAtoms';

const API_BASE_URL = 'http://localhost:8000/api';

export const fetchTradeEvents = async (): Promise<TradeEvent[]> => {
  try {
    const response = await axios.get<TradeEvent[]>(`${API_BASE_URL}/trade-events`);
    return response.data;
  } catch (error) {
    console.error('Error fetching trade events:', error);
    throw error;
  }
};

export const fetchTradeEventById = async (id: string): Promise<TradeEvent> => {
  try {
    const response = await axios.get<TradeEvent>(`${API_BASE_URL}/trade-events/${id}`);
    return response.data;
  } catch (error) {
    console.error(`Error fetching trade event with id ${id}:`, error);
    throw error;
  }
};
