// Import Jest DOM testing library to extend Jest's matchers
import '@testing-library/jest-dom';

// This file is run before each test file
// Add any global setup code here

// For example, if you need to mock global objects:
// global.fetch = jest.fn();

// Or if you need to set up specific behaviors:
// jest.setTimeout(10000); // increase timeout if needed
