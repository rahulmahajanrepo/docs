import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import ActionLinksRenderer from './ActionLinksRenderer';
import { ActionLinks } from '../state/tradeEventAtoms';

describe('ActionLinksRenderer', () => {
  // Mock window.open
  const originalOpen = window.open;
  beforeEach(() => {
    window.open = jest.fn();
  });
  
  afterEach(() => {
    window.open = originalOpen;
  });
  
  it('renders action links as buttons', () => {
    const actionLinks: ActionLinks = {
      View: 'https://example.com/view',
      Edit: 'https://example.com/edit',
    };
    
    render(
      <ActionLinksRenderer 
        value={actionLinks} 
        {...({} as any)} // Provide minimal required props from ICellRendererParams
      />
    );
    
    expect(screen.getByText('View')).toBeInTheDocument();
    expect(screen.getByText('Edit')).toBeInTheDocument();
  });
  
  it('opens the correct URL when a button is clicked', () => {
    const actionLinks: ActionLinks = {
      View: 'https://example.com/view',
    };
    
    render(
      <ActionLinksRenderer 
        value={actionLinks} 
        {...({} as any)}
      />
    );
    
    fireEvent.click(screen.getByText('View'));
    expect(window.open).toHaveBeenCalledWith('https://example.com/view', '_blank');
  });
  
  it('displays "No Actions" when value is undefined', () => {
    render(
      <ActionLinksRenderer 
        value={undefined as any} 
        {...({} as any)}
      />
    );
    
    expect(screen.getByText('No Actions')).toBeInTheDocument();
  });
  
  it('displays "No Actions" when value is null', () => {
    render(
      <ActionLinksRenderer 
        value={null as any} 
        {...({} as any)}
      />
    );
    
    expect(screen.getByText('No Actions')).toBeInTheDocument();
  });
  
  it('displays "No Actions" when value is not an object', () => {
    render(
      <ActionLinksRenderer 
        value={'string value' as any} 
        {...({} as any)}
      />
    );
    
    expect(screen.getByText('No Actions')).toBeInTheDocument();
  });
  
  it('renders correctly with empty action links object', () => {
    render(
      <ActionLinksRenderer 
        value={{}} 
        {...({} as any)}
      />
    );
    
    // No buttons should be rendered, but also no "No Actions" text
    const buttons = screen.queryAllByRole('button');
    expect(buttons.length).toBe(0);
    expect(screen.queryByText('No Actions')).not.toBeInTheDocument();
  });
});
