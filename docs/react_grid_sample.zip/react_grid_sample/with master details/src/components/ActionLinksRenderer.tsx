import React from 'react';
import { ICellRendererParams } from 'ag-grid-community';
import { ActionLinks } from '../state/tradeEventAtoms';

interface ActionLinksRendererProps extends ICellRendererParams {
  value: ActionLinks;
}

const ActionLinksRenderer: React.FC<ActionLinksRendererProps> = (props) => {
  const { value } = props;
  
  if (!value || typeof value !== 'object') {
    return <span>No Actions</span>;
  }
  
  return (
    <div>
      {Object.entries(value).map(([key, url]) => (
        <button 
          key={key}
          className="action-link-button"
          onClick={() => window.open(url, '_blank')}
        >
          {key}
        </button>
      ))}
    </div>
  );
};

export default ActionLinksRenderer;
