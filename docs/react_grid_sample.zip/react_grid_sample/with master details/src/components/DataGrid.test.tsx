import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { RecoilRoot, useRecoilValue } from 'recoil';
import DataGrid from './DataGrid';
import * as tradeEventAtoms from '../state/tradeEventAtoms';
import { tradeEventsState } from '../state/tradeEventAtoms';

// Mock recoil state and hooks
jest.mock('recoil', () => ({
  ...jest.requireActual('recoil'),
  useRecoilValue: jest.fn(),
}));

jest.mock('../state/tradeEventAtoms', () => ({
  ...jest.requireActual('../state/tradeEventAtoms'),
  useLoadTradeEvents: jest.fn(() => jest.fn()),
  tradeEventsState: {
    key: 'tradeEventsState',
    default: [],
  },
  tradeEventsLoadingState: {
    key: 'tradeEventsLoadingState',
    default: false,
  },
  tradeEventsErrorState: {
    key: 'tradeEventsErrorState',
    default: null,
  },
}));

describe('DataGrid Component', () => {
  const mockLoadTradeEvents = jest.fn();
  const mockTradeEvents = [
    {
      id: '1',
      name: 'Trade 1',
      type: 'Buy',
      symbol: 'AAPL',
      date: '2023-01-01',
    },
    {
      id: '2',
      name: 'Trade 2',
      type: 'Sell',
      symbol: 'GOOGL',
      date: '2023-01-02',
    },
  ];

  beforeEach(() => {
    jest.clearAllMocks();
    (tradeEventAtoms.useLoadTradeEvents as jest.Mock).mockImplementation(() => mockLoadTradeEvents);
    jest.spyOn(require('recoil'), 'useRecoilValue').mockImplementation((atom) => {
      if (atom === tradeEventsState) {
        return mockTradeEvents;
      }
      return false;
    });
  });

  it('renders the DataGrid component', () => {
    (useRecoilValue as jest.Mock).mockImplementation((atom: any) => {
      if (atom === tradeEventAtoms.tradeEventsState) return [];
      if (atom === tradeEventAtoms.tradeEventsLoadingState) return false;
      if (atom === tradeEventAtoms.tradeEventsErrorState) return null;
    });

    render(
      <RecoilRoot>
        <DataGrid />
      </RecoilRoot>
    );

    expect(screen.getByText('Trade Events')).toBeInTheDocument();
    expect(screen.getByText('Refresh')).toBeInTheDocument();
  });

  it('shows a loading indicator when loading', () => {
    (useRecoilValue as jest.Mock).mockImplementation((atom: any) => {
      if (atom === tradeEventAtoms.tradeEventsState) return [];
      if (atom === tradeEventAtoms.tradeEventsLoadingState) return true;
      if (atom === tradeEventAtoms.tradeEventsErrorState) return null;
    });

    render(
      <RecoilRoot>
        <DataGrid />
      </RecoilRoot>
    );

    expect(screen.getByText('Loading trade events...')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /loading/i })).toBeDisabled();
  });

  it('displays an error message when there is an error', () => {
    (useRecoilValue as jest.Mock).mockImplementation((atom: any) => {
      if (atom === tradeEventAtoms.tradeEventsState) return [];
      if (atom === tradeEventAtoms.tradeEventsLoadingState) return false;
      if (atom === tradeEventAtoms.tradeEventsErrorState) return 'Failed to load data';
    });

    render(
      <RecoilRoot>
        <DataGrid />
      </RecoilRoot>
    );

    expect(screen.getByText('Error Loading Trade Events')).toBeInTheDocument();
    expect(screen.getByText('Failed to load data')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /try again/i })).toBeInTheDocument();
  });

  it('renders trade events data when available', () => {
    const mockEvents = [
      { id: 1, name: 'Event 1', type: 'Type A', symbol: 'SYM1', date: '2023-01-01' },
      { id: 2, name: 'Event 2', type: 'Type B', symbol: 'SYM2', date: '2023-01-02' },
    ];
    (useRecoilValue as jest.Mock).mockImplementation((atom: any) => {
      if (atom === tradeEventAtoms.tradeEventsState) return mockEvents;
      if (atom === tradeEventAtoms.tradeEventsLoadingState) return false;
      if (atom === tradeEventAtoms.tradeEventsErrorState) return null;
    });

    render(
      <RecoilRoot>
        <DataGrid />
      </RecoilRoot>
    );

    expect(screen.getByText('Event 1')).toBeInTheDocument();
    expect(screen.getByText('Event 2')).toBeInTheDocument();
    expect(screen.queryByText('Event 3')).not.toBeInTheDocument();
  });

  it('calls the refresh function when the refresh button is clicked', () => {
    (useRecoilValue as jest.Mock).mockImplementation((atom: any) => {
      if (atom === tradeEventAtoms.tradeEventsState) return [];
      if (atom === tradeEventAtoms.tradeEventsLoadingState) return false;
      if (atom === tradeEventAtoms.tradeEventsErrorState) return null;
    });

    render(
      <RecoilRoot>
        <DataGrid />
      </RecoilRoot>
    );

    const refreshButton = screen.getByRole('button', { name: /refresh/i });
    fireEvent.click(refreshButton);

    expect(mockLoadTradeEvents).toHaveBeenCalledTimes(1);
  });

  it('displays a message when no trade events are available', () => {
    (useRecoilValue as jest.Mock).mockImplementation((atom: any) => {
      if (atom === tradeEventAtoms.tradeEventsState) return [];
      if (atom === tradeEventAtoms.tradeEventsLoadingState) return false;
      if (atom === tradeEventAtoms.tradeEventsErrorState) return null;
    });

    render(
      <RecoilRoot>
        <DataGrid />
      </RecoilRoot>
    );

    expect(screen.getByText('No trade events data available')).toBeInTheDocument();
  });

  it('renders the grid with rows', () => {
    render(
      <RecoilRoot>
        <DataGrid />
      </RecoilRoot>
    );

    // Verify rows are rendered
    expect(screen.getByText('Trade 1')).toBeInTheDocument();
    expect(screen.getByText('Trade 2')).toBeInTheDocument();
  });

  it('renders detailCellRenderer when a row is expanded', async () => {
    render(
      <RecoilRoot>
        <DataGrid />
      </RecoilRoot>
    );

    // Expand the first row
    const firstRow = screen.getByText('Trade 1');
    fireEvent.click(firstRow);

    // Wait for the detail view to render
    await waitFor(() => {
      expect(screen.getByText('Details for Trade 1')).toBeInTheDocument();
    });

    // Verify details in the expanded view
    expect(screen.getByText('Type: Buy')).toBeInTheDocument();
    expect(screen.getByText('Symbol: AAPL')).toBeInTheDocument();
    expect(screen.getByText('Date: 2023-01-01')).toBeInTheDocument();
    expect(screen.getByText('ID: 1')).toBeInTheDocument();
  });

  it('toggles detailCellRenderer when the same row is clicked again', async () => {
    render(
      <RecoilRoot>
        <DataGrid />
      </RecoilRoot>
    );

    // Expand the first row
    const firstRow = screen.getByText('Trade 1');
    fireEvent.click(firstRow);

    // Wait for the detail view to render
    await waitFor(() => {
      expect(screen.getByText('Details for Trade 1')).toBeInTheDocument();
    });

    // Collapse the row by clicking it again
    fireEvent.click(firstRow);

    // Wait for the detail view to disappear
    await waitFor(() => {
      expect(screen.queryByText('Details for Trade 1')).not.toBeInTheDocument();
    });
  });
});
