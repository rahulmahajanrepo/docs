# Installation Instructions

## Install Axios

Run the following command in your project root directory to install Axios:

```bash
npm install axios
```

Or if you're using Yarn:

```bash
yarn add axios
```

## Restart Development Server

After installing the dependencies, restart your development server:

```bash
npm start
```

Or with Yarn:

```bash
yarn start
```

This should resolve the "Module not found" error for Axios.
