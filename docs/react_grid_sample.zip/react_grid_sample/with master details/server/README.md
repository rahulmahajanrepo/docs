# Trade Events API Server Setup

This document explains how to set up the Python virtual environment for the Trade Events API server.

## Creating a Virtual Environment

### Windows

```bash
# Navigate to the server directory
cd c:\dev\react\react-grid-recoil\server

# Create a virtual environment
python -m venv venv

# Activate the virtual environment
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### macOS/Linux

```bash
# Navigate to the server directory
cd /path/to/react-grid-recoil/server

# Create a virtual environment
python3 -m venv venv

# Activate the virtual environment
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

## Verifying the Installation

After activating the virtual environment and installing dependencies, you can verify everything is working by:

```bash
# Make sure you're in the server directory with the virtual environment activated
python -c "import fastapi, uvicorn, pydantic; print('All dependencies successfully installed!')"
```

## Running the Server

```bash
# Make sure you're in the server directory with the virtual environment activated
python app.py
```

The server will be available at http://localhost:8000

## API Documentation

FastAPI automatically generates API documentation. After starting the server, you can access:
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## Deactivating the Virtual Environment

When you're done working with the server, you can deactivate the virtual environment:

```bash
deactivate
```
