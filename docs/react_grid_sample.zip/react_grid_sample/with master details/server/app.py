from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Dict, List
import uvicorn
from datetime import datetime, timedelta
import random

app = FastAPI(title="TradeEvent API")

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, replace with specific origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class TradeEvent(BaseModel):
    id: str
    name: str
    type: str
    symbol: str
    date: str
    actionLinks: Dict[str, str]

# Sample data
trade_events = [
    TradeEvent(
        id="1",
        name="Bitcoin",
        type="Cryptocurrency",
        symbol="BTC",
        date=(datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d"),
        actionLinks={
            "View Details": "https://example.com/bitcoin",
            "Price Chart": "https://example.com/bitcoin/chart",
            "Trade Now": "https://example.com/bitcoin/trade"
        }
    ),
    TradeEvent(
        id="2",
        name="Ethereum",
        type="Cryptocurrency",
        symbol="ETH",
        date=(datetime.now() - timedelta(days=2)).strftime("%Y-%m-%d"),
        actionLinks={
            "View Details": "https://example.com/ethereum",
            "Price Chart": "https://example.com/ethereum/chart",
            "Trade Now": "https://example.com/ethereum/trade"
        }
    ),
    TradeEvent(
        id="3",
        name="Apple",
        type="Stock",
        symbol="AAPL",
        date=datetime.now().strftime("%Y-%m-%d"),
        actionLinks={
            "View Details": "https://example.com/apple",
            "Price Chart": "https://example.com/apple/chart",
            "Buy": "https://example.com/apple/buy"
        }
    ),
    TradeEvent(
        id="4",
        name="Tesla",
        type="Stock",
        symbol="TSLA",
        date=(datetime.now() - timedelta(days=3)).strftime("%Y-%m-%d"),
        actionLinks={
            "View Details": "https://example.com/tesla",
            "Price Chart": "https://example.com/tesla/chart",
            "Buy": "https://example.com/tesla/buy"
        }
    ),
    TradeEvent(
        id="5",
        name="Gold",
        type="Commodity",
        symbol="GC",
        date=(datetime.now() - timedelta(days=5)).strftime("%Y-%m-%d"),
        actionLinks={
            "View Details": "https://example.com/gold",
            "Price Chart": "https://example.com/gold/chart"
        }
    ),
]

@app.get("/")
async def root():
    return {"message": "TradeEvent API is running"}

@app.get("/api/trade-events", response_model=List[TradeEvent])
async def get_trade_events():
    return trade_events

@app.get("/api/trade-events/{event_id}", response_model=TradeEvent)
async def get_trade_event(event_id: str):
    for event in trade_events:
        if event.id == event_id:
            return event
    raise HTTPException(status_code=404, detail="TradeEvent not found")

if __name__ == "__main__":
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)
