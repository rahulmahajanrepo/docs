import React from 'react';
import { useRecoilState } from 'recoil';
import { selectedFormState, activeTabState } from './state/atoms';
import './App.css';

// Import and use web components
import 'form-builder';

// Register web components types for TypeScript
declare global {
  namespace JSX {
    interface IntrinsicElements {
      'form-designer': React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>;
      'form-renderer': React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement> & { 
        'form-name'?: string 
      }, HTMLElement>;
    }
  }
}

const App: React.FC = () => {
  const [selectedForm, setSelectedForm] = useRecoilState(selectedFormState);
  const [activeTab, setActiveTab] = useRecoilState(activeTabState);

  const switchTab = (tab: string) => {
    setActiveTab(tab);
  };

  return (
    <div className="app-container">
      <header>
        <h1>Form Builder Demo</h1>
        <div className="tab-navigation">
          <button 
            className={`tab-button ${activeTab === 'designer' ? 'active' : ''}`}
            onClick={() => switchTab('designer')}
          >
            Form Designer
          </button>
          <button 
            className={`tab-button ${activeTab === 'renderer' ? 'active' : ''}`}
            onClick={() => switchTab('renderer')}
          >
            Form Renderer
          </button>
        </div>
      </header>
      
      <div className="tab-content">
        {activeTab === 'designer' && (
          <section className="tab-section">
            <form-designer></form-designer>
          </section>
        )}
        
        {activeTab === 'renderer' && (
          <section className="tab-section">
            <form-renderer form-name={selectedForm}></form-renderer>
          </section>
        )}
      </div>
    </div>
  );
};

export default App;
