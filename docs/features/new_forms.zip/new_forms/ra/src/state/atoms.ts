import { atom } from 'recoil';

export const selectedFormState = atom({
  key: 'selectedFormState',
  default: 'Sample Form'
});

export const activeTabState = atom({
  key: 'activeTabState',
  default: 'designer' // 'designer' or 'renderer'
});
