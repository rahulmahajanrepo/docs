/**
 * Converts a camelCase or snake_case object name to a readable title.
 * Example: "initialAmount" -> "Initial Amount"
 * Example: "user_first_name" -> "User First Name"
 */
export function objectNameToTitle(objectName: string): string {
  if (!objectName) return '';
  
  // First, handle camelCase by adding spaces before capital letters
  const withSpaces = objectName.replace(/([A-Z])/g, ' $1');
  
  // Handle snake_case by replacing underscores with spaces
  const withoutUnderscores = withSpaces.replace(/_/g, ' ');
  
  // Capitalize the first letter of each word and trim extra spaces
  return withoutUnderscores
    .trim()
    .split(' ')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
}
