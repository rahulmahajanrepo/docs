import { AnyComponent, ComponentCategory, SectionType } from '../models/component-types';
import { VisibilityCondition, SimpleCondition, ComplexCondition, LogicalOperator } from '../models/visibility-conditions';

export interface Node {
  id: string;
  label: string;
  type: string;
}

export interface Edge {
  source: string;
  target: string;
  label: string;
}

export interface DAG {
  nodes: Node[];
  edges: Edge[];
}

export function buildDependencyDAG(components: Record<string, AnyComponent>): DAG {
  const nodes: Node[] = [];
  const edges: Edge[] = [];
  
  // First, create nodes for all components
  Object.values(components).forEach(component => {
    nodes.push({
      id: component.id,
      label: component.title || 'Unnamed Component',
      type: component.category === ComponentCategory.Section ? 'section' : 'component'
    });
  });
  
  // Then, create edges for parent-child relationships
  Object.values(components).forEach(component => {
    if (component.parentId) {
      edges.push({
        source: component.parentId,
        target: component.id,
        label: 'contains'
      });
    }
  });
  
  // Finally, add edges for visibility conditions
  Object.values(components).forEach(component => {
    if (component.category === ComponentCategory.Section && 'visibilityCondition' in component) {
      const condition = (component as any).visibilityCondition as VisibilityCondition | undefined;
      if (condition) {
        addConditionEdges(condition, component.id, edges);
      }
    }
  });
  
  return { nodes, edges };
}

function addConditionEdges(
  condition: VisibilityCondition,
  targetId: string,
  edges: Edge[]
) {
  if ('logicalOperator' in condition) {
    // It's a complex condition
    const complexCondition = condition as ComplexCondition;
    complexCondition.conditions.forEach(subCondition => {
      addConditionEdges(subCondition, targetId, edges);
    });
  } else {
    // It's a simple condition
    const simpleCondition = condition as SimpleCondition;
    edges.push({
      source: simpleCondition.targetComponentId,
      target: targetId,
      label: `depends on (${simpleCondition.operator})`
    });
  }
}

// Validate that the dependency graph doesn't have cycles
export function validateDAG(dag: DAG): boolean {
  // Use a topological sort to detect cycles
  const { nodes, edges } = dag;
  
  // Map of node IDs to their dependencies count
  const inDegree: Record<string, number> = {};
  
  // Initialize all nodes with in-degree 0
  nodes.forEach(node => {
    inDegree[node.id] = 0;
  });
  
  // Count dependencies for each node
  edges.forEach(edge => {
    inDegree[edge.target] = (inDegree[edge.target] || 0) + 1;
  });
  
  // Queue of nodes with no dependencies
  const queue: string[] = [];
  
  // Start with nodes that have no dependencies
  Object.entries(inDegree).forEach(([nodeId, degree]) => {
    if (degree === 0) {
      queue.push(nodeId);
    }
  });
  
  // Count of visited nodes
  let visitedCount = 0;
  
  while (queue.length > 0) {
    const currentNode = queue.shift()!;
    visitedCount++;
    
    // Find all edges where this node is the source
    edges.filter(edge => edge.source === currentNode).forEach(edge => {
      // Reduce in-degree of target node
      inDegree[edge.target]--;
      
      // If target has no more dependencies, add to queue
      if (inDegree[edge.target] === 0) {
        queue.push(edge.target);
      }
    });
  }
  
  // If we've visited all nodes, there's no cycle
  return visitedCount === nodes.length;
}
