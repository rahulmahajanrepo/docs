import { store } from '../state/store';
import { ComponentCategory, AnyComponent, SectionType } from '../models/component-types';

// Data transfer format for drag and drop operations
export interface DragData {
  id?: string;                   // Component ID (if existing component)
  componentType?: string;        // Component type (if creating new component)
  category?: ComponentCategory;  // Component category (if creating new component)
  sourceParentId?: string | null; // Parent ID of source (for existing components)
  sourceOrder?: number;          // Order in source parent (for existing components)
}

// Add drag data to dataTransfer object
export function setDragData(dataTransfer: DataTransfer, data: DragData): void {
  dataTransfer.setData('application/json', JSON.stringify(data));
  
  // Add markers for easier type detection
  if (data.category === ComponentCategory.Section) {
    dataTransfer.setData('section-marker', 'true');
    
    // Add additional marker for subsection
    if (data.componentType === SectionType.SubSection || 
        (data.id && isSubSection(data.id))) {
      dataTransfer.setData('subsection-marker', 'true');
    }
  } else {
    dataTransfer.setData('component-marker', 'true');
  }
}

// Helper to check if a component is a section
function isSectionComponent(id: string): boolean {
  const state = store.getState();
  const component = state.formMetadata.components[id];
  return component?.category === ComponentCategory.Section;
}

// Helper to determine if an ID is a subsection
export function isSubSection(id: string): boolean {
  const state = store.getState();
  const component = state.formMetadata.components[id];
  return component?.category === ComponentCategory.Section && 
         component?.type === SectionType.SubSection;
}

// Retrieve drag data from dataTransfer object
export function getDragData(dataTransfer: DataTransfer): DragData | null {
  try {
    const data = dataTransfer.getData('application/json');
    return data ? JSON.parse(data) : null;
  } catch (error) {
    console.error('Error parsing drag data:', error);
    return null;
  }
}

// Check if the dragged item is a section
export function isSectionDrag(dataTransfer: DataTransfer): boolean {
  return dataTransfer.types.includes('section-marker');
}

// Check if the dragged item is a component (non-section)
export function isComponentDrag(dataTransfer: DataTransfer): boolean {
  return dataTransfer.types.includes('component-marker');
}

// Check if the dragged item is a subsection
export function isSubSectionDrag(dataTransfer: DataTransfer): boolean {
  return dataTransfer.types.includes('subsection-marker');
}

// Handle drag start event with enhanced visual feedback
export function handleDragStart(
  event: DragEvent, 
  data: DragData
): void {
  if (!event.dataTransfer) return;
  
  // Log component details being dragged
  console.log('Drag started with component data:', data);
  
  // If it's an existing component, get more details from store
  if (data.id) {
    const state = store.getState();
    const component = state.formMetadata.components[data.id];
    if (component) {
      console.log('Component details:', {
        id: component.id,
        title: component.title,
        type: component.type,
        category: component.category,
        parentId: component.parentId
      });
    }
  }
  
  // Clear any existing body classes
  document.body.classList.remove('dragging-section', 'dragging-component');
  
  // Add drag data
  setDragData(event.dataTransfer, data);
  
  // Set body class for global style adjustments
  const isSection = 
    data.category === ComponentCategory.Section || 
    (data.id && isSectionComponent(data.id));
  
  document.body.classList.add(isSection ? 'dragging-section' : 'dragging-component');
  
  // Set drag effect
  event.dataTransfer.effectAllowed = 'move';
  
  // Create a better ghost image
  if (event.target instanceof HTMLElement) {
    // Create a clean ghost element instead of cloning
    const ghost = document.createElement('div');
    
    // Copy just the text content for a cleaner ghost
    const sourceText = event.target.textContent?.trim() || '';
    const iconElement = event.target.querySelector('.icon');
    const iconText = iconElement ? iconElement.textContent || '' : '';
    
    // Basic ghost styling
    ghost.style.padding = '8px 12px';
    ghost.style.background = isSection ? '#fff3e0' : '#e3f2fd';
    ghost.style.border = isSection ? '2px solid #ff9800' : '2px solid #4285f4';
    ghost.style.borderRadius = '6px';
    ghost.style.fontSize = '14px';
    ghost.style.fontFamily = "'Segoe UI', Roboto, -apple-system, BlinkMacSystemFont, sans-serif";
    ghost.style.color = '#333';
    ghost.style.boxShadow = '0 2px 8px rgba(0,0,0,0.15)';
    ghost.style.position = 'absolute';
    ghost.style.top = '0';
    ghost.style.left = '0';
    ghost.style.zIndex = '9999';
    ghost.style.pointerEvents = 'none';
    ghost.style.display = 'flex';
    ghost.style.alignItems = 'center';
    ghost.style.opacity = '0.9';
    ghost.style.maxWidth = '200px';
    ghost.style.whiteSpace = 'nowrap';
    ghost.style.overflow = 'hidden';
    ghost.style.textOverflow = 'ellipsis';
    
    // Add content with icon if available
    if (iconText) {
      ghost.innerHTML = `<span style="margin-right:8px;font-size:16px;">${iconText}</span>${sourceText.replace(iconText, '')}`;
    } else {
      ghost.textContent = sourceText;
    }
    
    // Append to document and use as drag image
    document.body.appendChild(ghost);
    
    // Position the grab point near the cursor
    const offsetX = 10;
    const offsetY = 10;
    event.dataTransfer.setDragImage(ghost, offsetX, offsetY);
    
    // Clean up the ghost element after drag starts
    setTimeout(() => {
      document.body.removeChild(ghost);
    }, 0);
  }
}

// Check if a drop is allowed in the target section
export function isDropAllowed(
  dragData: DragData,
  targetSectionId: string | null
): boolean {
  const state = store.getState();
  const { components } = state.formMetadata;
  
  // If creating a new component, always allow drop
  if (!dragData.id) return true;
  
  // Don't allow dropping a component into itself
  if (dragData.id === targetSectionId) return false;
  
  // Get the component being dragged
  const draggedComponent = components[dragData.id];
  if (!draggedComponent) return true; // If component not found, allow drop
  
  console.log("Dragged component:", draggedComponent.category, draggedComponent.type);
  
  // CASE 1: Primitive and Complex components should always be allowed to move between sections
  if (draggedComponent.category === ComponentCategory.Primitive || 
      draggedComponent.category === ComponentCategory.Complex) {
    console.log("Allowing primitive/complex component drop");
    return true;
  }
  
  // CASE 2: SubSections can be dropped into any section but not into themselves
  if (draggedComponent.category === ComponentCategory.Section && 
      draggedComponent.type === SectionType.SubSection) {
    console.log("Checking subsection drop");
    // Only perform basic self-reference check
    return draggedComponent.id !== targetSectionId;
  }
  
  // CASE 3: Regular Sections can't be dropped into any section
  if (draggedComponent.category === ComponentCategory.Section && 
      draggedComponent.type === SectionType.Section) {
    console.log("Checking section drop");
    if (targetSectionId !== null) {
      return false;
    }
    
    // No need to check for circular references if we're dropping at the root level
    return true;
  }
  
  // Default to allowing the drop
  console.log("Default case: allowing drop");
  return true;
}

// Add a debugging function to help troubleshoot drag and drop issues
export function debugDragData(dataTransfer: DataTransfer): void {
  console.log("DataTransfer types:", dataTransfer.types);
  console.log("Is section drag:", isSectionDrag(dataTransfer));
  console.log("Is component drag:", isComponentDrag(dataTransfer));
  
  try {
    const data = getDragData(dataTransfer);
    console.log("Drag data:", data);
  } catch (e) {
    console.error("Error parsing drag data:", e);
  }
}
