import { createStore } from 'redux';
import { v4 as uuidv4 } from 'uuid';
import { AnyComponent, ComponentCategory, SectionType } from '../models/component-types';
import { FormMetadata } from '../models/form-metadata';

import { 
  ADD_COMPONENT, 
  UPDATE_COMPONENT, 
  DELETE_COMPONENT, 
  SELECT_COMPONENT, 
  MOVE_COMPONENT,
  SET_VISIBILITY_CONDITION,
  ADD_VALIDATION_RULE,
  REMOVE_VALIDATION_RULE,
  SET_FORM_METADATA
} from './actions';

export interface FormState {
  formMetadata: FormMetadata;
  selectedComponentId: string | null;
  isDragging: boolean;
  draggedComponentId: string | null;
  showMetadataViewer: boolean;
  showDagViewer: boolean;
}

// Create default form metadata with one section
const createDefaultFormMetadata = (): FormMetadata => {
  const sectionId = uuidv4();
  const now = new Date().toISOString();
  
  // Create default section
  const defaultSection: AnyComponent = {
    id: sectionId,
    category: ComponentCategory.Section,
    type: SectionType.Section,
    objectName: 'defaultSection',
    title: 'Default Section',
    order: 0,
    parentId: null,
    components: []
  };
  
  return {
    id: uuidv4(),
    name: 'New Form',
    version: '1.0',
    description: 'Created with Form Builder',
    components: { [sectionId]: defaultSection },
    rootSections: [sectionId],
    createdAt: now,
    updatedAt: now
  };
};

// Initial state
const initialState: FormState = {
  formMetadata: createDefaultFormMetadata(),
  selectedComponentId: null,
  isDragging: false,
  draggedComponentId: null,
  showMetadataViewer: false,
  showDagViewer: false
};

// Helper function to reorder components in a section
const reorderComponents = (components: Record<string, AnyComponent>, parentId: string | null): string[] => {
  return Object.values(components)
    .filter(c => c.parentId === parentId)
    .sort((a, b) => a.order - b.order)
    .map(c => c.id);
};

// Reducer
function formReducer(state = initialState, action: any): FormState {
  switch (action.type) {
    case ADD_COMPONENT: {
      const component = action.payload as AnyComponent;
      const updatedComponents = { ...state.formMetadata.components };
      
      // Calculate order based on existing components in the parent
      const siblingComponents = Object.values(updatedComponents)
        .filter(c => c.parentId === component.parentId);
      component.order = siblingComponents.length;
      
      // Add component to store
      updatedComponents[component.id] = component;
      
      // If it's being added to a section, update that section's components array
      if (component.parentId) {
        const parentSection = updatedComponents[component.parentId];
        if (parentSection && parentSection.category === ComponentCategory.Section) {
          const parentSectionCopy = { ...parentSection };
          parentSectionCopy.components = [...parentSectionCopy.components, component.id];
          updatedComponents[component.parentId] = parentSectionCopy;
        }
      }
      
      return {
        ...state,
        formMetadata: {
          ...state.formMetadata,
          components: updatedComponents,
          // If it's a root section, add it to rootSections
          rootSections: component.category === ComponentCategory.Section && component.parentId === null
            ? [...state.formMetadata.rootSections, component.id]
            : state.formMetadata.rootSections,
          updatedAt: new Date().toISOString()
        },
        selectedComponentId: component.id // Auto-select newly added component
      };
    }
    
    case UPDATE_COMPONENT: {
      const { id, updates } = action.payload;
      const updatedComponents = { ...state.formMetadata.components };
      
      if (updatedComponents[id]) {
        updatedComponents[id] = {
          ...updatedComponents[id],
          ...updates,
          // Always update the timestamp when a component changes
          updatedAt: new Date().toISOString()
        };
        
        return {
          ...state,
          formMetadata: {
            ...state.formMetadata,
            components: updatedComponents,
            updatedAt: new Date().toISOString()
          }
        };
      }
      return state;
    }
    
    case DELETE_COMPONENT: {
      const id = action.payload;
      const updatedComponents = { ...state.formMetadata.components };
      
      // If component doesn't exist, do nothing
      if (!updatedComponents[id]) return state;
      
      const component = updatedComponents[id];
      
      // If this is a section, recursively delete all its child components
      if (component.category === ComponentCategory.Section) {
        const componentsToDelete = [id];
        
        // Find all components that are children of this section
        const findChildComponents = (sectionId: string) => {
          const section = updatedComponents[sectionId] as any;
          if (section?.components) {
            section.components.forEach((childId: string) => {
              componentsToDelete.push(childId);
              const child = updatedComponents[childId];
              // If child is also a section, recursively find its children
              if (child?.category === ComponentCategory.Section) {
                findChildComponents(childId);
              }
            });
          }
        };
        
        findChildComponents(id);
        
        // Delete all found components
        componentsToDelete.forEach(cId => {
          delete updatedComponents[cId];
        });
        
        // Update parent section's components array (if applicable)
        if (component.parentId && updatedComponents[component.parentId]) {
          const parentSection = updatedComponents[component.parentId] as any;
          if (parentSection.components) {
            parentSection.components = parentSection.components.filter(
              (cId: string) => cId !== id
            );
          }
        }
        
        // Update rootSections if this was a root section
        const rootSections = state.formMetadata.rootSections.filter(sId => sId !== id);
        
        return {
          ...state,
          formMetadata: {
            ...state.formMetadata,
            components: updatedComponents,
            rootSections,
            updatedAt: new Date().toISOString()
          },
          selectedComponentId: state.selectedComponentId === id ? null : state.selectedComponentId
        };
      }
      
      // For non-section components, just remove from store and parent
      delete updatedComponents[id];
      
      // Update parent section's components array (if applicable)
      if (component.parentId && updatedComponents[component.parentId]) {
        const parentSection = updatedComponents[component.parentId] as any;
        if (parentSection.components) {
          parentSection.components = parentSection.components.filter(
            (cId: string) => cId !== id
          );
        }
      }
      
      return {
        ...state,
        formMetadata: {
          ...state.formMetadata,
          components: updatedComponents,
          updatedAt: new Date().toISOString()
        },
        selectedComponentId: state.selectedComponentId === id ? null : state.selectedComponentId
      };
    }
    
    case SELECT_COMPONENT:
      return {
        ...state,
        selectedComponentId: action.payload
      };
    
    case MOVE_COMPONENT: {
      const { id, newParentId, newOrder } = action.payload;
      const updatedComponents = { ...state.formMetadata.components };
      
      // Component must exist to be moved
      if (!updatedComponents[id]) return state;
      
      const component = updatedComponents[id];
      const oldParentId = component.parentId;
      
      // If parent is changing, update both old and new parent sections
      if (oldParentId !== newParentId) {
        // Remove from old parent
        if (oldParentId && updatedComponents[oldParentId]) {
          const oldParent = { ...updatedComponents[oldParentId] } as any;
          oldParent.components = oldParent.components.filter((cId: string) => cId !== id);
          updatedComponents[oldParentId] = oldParent;
        }
        
        // Add to new parent
        if (newParentId && updatedComponents[newParentId]) {
          const newParent = { ...updatedComponents[newParentId] } as any;
          newParent.components = [...newParent.components, id];
          updatedComponents[newParentId] = newParent;
        }
        
        // If moving to/from being a root section
        let rootSections = [...state.formMetadata.rootSections];
        
        // If old parent was null and new parent isn't, remove from root
        if (oldParentId === null && newParentId !== null) {
          rootSections = rootSections.filter(sId => sId !== id);
        }
        
        // If new parent is null and old parent wasn't, add to root
        if (newParentId === null && oldParentId !== null) {
          rootSections = [...rootSections, id];
        }
        
        // Update component's parent
        updatedComponents[id] = {
          ...component,
          parentId: newParentId,
          order: newOrder
        };
        
        return {
          ...state,
          formMetadata: {
            ...state.formMetadata,
            components: updatedComponents,
            rootSections,
            updatedAt: new Date().toISOString()
          }
        };
      }
      
      // If just reordering within the same parent
      updatedComponents[id] = {
        ...component,
        order: newOrder
      };
      
      // Get all components at the same level and update their orders
      const siblingsIds = newParentId === null
        ? state.formMetadata.rootSections
        : (updatedComponents[newParentId] as any)?.components || [];
        
      const siblingComponents = siblingsIds
        .map((siblingId: string) => updatedComponents[siblingId])
        .filter(Boolean)
        .sort((a: any, b: any) => a.order - b.order);
      
      // Remove the moved component from the array
      const filteredSiblings = siblingComponents.filter((c: any) => c.id !== id);
      
      // Insert it at the new position
      filteredSiblings.splice(newOrder, 0, updatedComponents[id]);
      
      // Update all siblings with new order values
      filteredSiblings.forEach((sibling: any, index: number) => {
        updatedComponents[sibling.id] = {
          ...updatedComponents[sibling.id],
          order: index
        };
      });
      
      return {
        ...state,
        formMetadata: {
          ...state.formMetadata,
          components: updatedComponents,
          updatedAt: new Date().toISOString()
        }
      };
    }
    
    case SET_VISIBILITY_CONDITION: {
      const { id, condition } = action.payload;
      const updatedComponents = { ...state.formMetadata.components };
      
      if (updatedComponents[id]) {
        const component = updatedComponents[id] as any;
        
        if (component.category === ComponentCategory.Section) {
          updatedComponents[id] = {
            ...component,
            visibilityCondition: condition
          };
          
          return {
            ...state,
            formMetadata: {
              ...state.formMetadata,
              components: updatedComponents,
              updatedAt: new Date().toISOString()
            }
          };
        }
      }
      
      return state;
    }
    
    case ADD_VALIDATION_RULE: {
      const { componentId, rule } = action.payload;
      const updatedComponents = { ...state.formMetadata.components };
      
      if (updatedComponents[componentId]) {
        const component = updatedComponents[componentId] as any;
        const validation = component.validation || [];
        
        updatedComponents[componentId] = {
          ...component,
          validation: [...validation, rule]
        };
        
        return {
          ...state,
          formMetadata: {
            ...state.formMetadata,
            components: updatedComponents,
            updatedAt: new Date().toISOString()
          }
        };
      }
      
      return state;
    }
    
    case REMOVE_VALIDATION_RULE: {
      const { componentId, ruleIndex } = action.payload;
      const updatedComponents = { ...state.formMetadata.components };
      
      if (updatedComponents[componentId]) {
        const component = updatedComponents[componentId] as any;
        
        if (component.validation && component.validation.length > ruleIndex) {
          const validation = [...component.validation];
          validation.splice(ruleIndex, 1);
          
          updatedComponents[componentId] = {
            ...component,
            validation
          };
          
          return {
            ...state,
            formMetadata: {
              ...state.formMetadata,
              components: updatedComponents,
              updatedAt: new Date().toISOString()
            }
          };
        }
      }
      
      return state;
    }
    
    case SET_FORM_METADATA:
      return {
        ...state,
        formMetadata: action.payload,
        selectedComponentId: null
      };
    
    default:
      return state;
  }
}

// Create store
export const store = createStore(
  formReducer,
  typeof window !== 'undefined' && 
  (window as any).__REDUX_DEVTOOLS_EXTENSION__ && 
  (window as any).__REDUX_DEVTOOLS_EXTENSION__()
);

// Subscribe to store changes in component
export function connectStore(
  component: HTMLElement, 
  selector: (state: FormState) => any,
  onChange: (selectedState: any) => void
) {
  let currentState = selector(store.getState());
  
  const handleChange = () => {
    const newState = selector(store.getState());
    if (JSON.stringify(newState) !== JSON.stringify(currentState)) {
      currentState = newState;
      onChange(newState);
    }
  };
  
  const unsubscribe = store.subscribe(handleChange);
  
  // Initial call
  onChange(currentState);
  
  // Return unsubscribe function
  return unsubscribe;
}
