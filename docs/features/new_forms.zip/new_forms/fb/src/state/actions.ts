import { AnyComponent, ComponentCategory, PrimitiveType, ComplexType, SectionType } from '../models/component-types';
import { VisibilityCondition } from '../models/visibility-conditions';
import { ValidationRule } from '../models/validation-rules';
import { v4 as uuidv4 } from 'uuid';

// Action Types
export const ADD_COMPONENT = 'ADD_COMPONENT';
export const UPDATE_COMPONENT = 'UPDATE_COMPONENT';
export const DELETE_COMPONENT = 'DELETE_COMPONENT';
export const SELECT_COMPONENT = 'SELECT_COMPONENT';
export const MOVE_COMPONENT = 'MOVE_COMPONENT';
export const SET_VISIBILITY_CONDITION = 'SET_VISIBILITY_CONDITION';
export const ADD_VALIDATION_RULE = 'ADD_VALIDATION_RULE';
export const REMOVE_VALIDATION_RULE = 'REMOVE_VALIDATION_RULE';
export const SET_FORM_METADATA = 'SET_FORM_METADATA';
export const EXPORT_METADATA = 'EXPORT_METADATA';

export interface Component {
  type: string;
  id: string;
  properties: Record<string, any>;
}

// Action Creators
export const addComponent = (
  componentType: string, 
  category: ComponentCategory, 
  parentId: string | null = null,
  properties: Partial<AnyComponent> = {}
) => {
  const id = uuidv4();
  const now = new Date();
  
  let component: AnyComponent;
  
  switch (category) {
    case ComponentCategory.Primitive:
      component = {
        id,
        category,
        type: componentType as PrimitiveType,
        objectName: `field_${id.slice(0, 8)}`,
        title: `New ${componentType}`,
        order: 0,
        parentId,
        ...properties
      } as AnyComponent;
      break;
      
    case ComponentCategory.Complex:
      component = {
        id,
        category,
        type: componentType as ComplexType,
        objectName: `complex_${id.slice(0, 8)}`,
        title: `New ${componentType}`,
        order: 0,
        parentId,
        ...properties
      } as AnyComponent;
      break;
      
    case ComponentCategory.Section:
      component = {
        id,
        category,
        type: componentType as SectionType,
        objectName: `section_${id.slice(0, 8)}`,
        title: `New ${componentType}`,
        order: 0,
        parentId,
        components: [],
        ...properties
      } as AnyComponent;
      break;
      
    default:
      throw new Error(`Unknown component category: ${category}`);
  }
  
  return {
    type: ADD_COMPONENT,
    payload: component
  };
};

export const updateComponent = (id: string, updates: Partial<AnyComponent>) => ({
  type: UPDATE_COMPONENT,
  payload: { id, updates }
});

export const deleteComponent = (id: string) => ({
  type: DELETE_COMPONENT,
  payload: id
});

export const selectComponent = (id: string | null) => ({
  type: SELECT_COMPONENT,
  payload: id
});

export const moveComponent = (id: string, newParentId: string | null, newOrder: number) => ({
  type: MOVE_COMPONENT,
  payload: { id, newParentId, newOrder }
});

export const setVisibilityCondition = (id: string, condition: VisibilityCondition | null) => ({
  type: SET_VISIBILITY_CONDITION,
  payload: { id, condition }
});

export const addValidationRule = (componentId: string, rule: ValidationRule) => ({
  type: ADD_VALIDATION_RULE,
  payload: { componentId, rule }
});

export const removeValidationRule = (componentId: string, ruleIndex: number) => ({
  type: REMOVE_VALIDATION_RULE,
  payload: { componentId, ruleIndex }
});

export const setFormMetadata = (metadata: any) => ({
  type: SET_FORM_METADATA,
  payload: metadata
});

export const exportMetadata = () => ({
  type: EXPORT_METADATA
});
