export enum ValidationRuleType {
  Required = 'required',
  MinLength = 'minLength',
  MaxLength = 'maxLength',
  Pattern = 'pattern',
  Min = 'min',
  Max = 'max',
  Email = 'email',
  Custom = 'custom'
}

export interface BaseValidationRule {
  type: ValidationRuleType;
  message: string;
}

export interface RequiredRule extends BaseValidationRule {
  type: ValidationRuleType.Required;
}

export interface MinLengthRule extends BaseValidationRule {
  type: ValidationRuleType.MinLength;
  minLength: number;
}

export interface MaxLengthRule extends BaseValidationRule {
  type: ValidationRuleType.MaxLength;
  maxLength: number;
}

export interface PatternRule extends BaseValidationRule {
  type: ValidationRuleType.Pattern;
  pattern: string;
}

export interface MinRule extends BaseValidationRule {
  type: ValidationRuleType.Min;
  min: number;
}

export interface MaxRule extends BaseValidationRule {
  type: ValidationRuleType.Max;
  max: number;
}

export interface EmailRule extends BaseValidationRule {
  type: ValidationRuleType.Email;
}

export interface CustomRule extends BaseValidationRule {
  type: ValidationRuleType.Custom;
  validatorFn: string; // Serialized function
}

export type ValidationRule = 
  | RequiredRule
  | MinLengthRule
  | MaxLengthRule
  | PatternRule
  | MinRule
  | MaxRule
  | EmailRule
  | CustomRule;
