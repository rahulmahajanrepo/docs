import { ValidationRule } from './validation-rules';
import { VisibilityCondition } from './visibility-conditions';

export enum ComponentCategory {
  Primitive = 'primitive',
  Complex = 'complex',
  Section = 'section'
}

export enum PrimitiveType {
  Text = 'text',
  LongText = 'longText',
  Number = 'number',
  Decimal = 'decimal',
  Date = 'date',
  Radio = 'radio',
  Boolean = 'boolean',
  Dropdown = 'dropdown'
}

export enum ComplexType {
  List = 'list',
  KeyValue = 'keyValue',
  Grid = 'grid'
}

export enum SectionType {
  Section = 'section',
  SubSection = 'subSection'
}

export enum DataType {
  String = 'string',
  Number = 'number',
  Boolean = 'boolean',
  Date = 'date',
  Object = 'object',
  Array = 'array'
}

export interface BaseComponent {
  id: string;
  type: string;
  objectName: string; // The key name in the resulting JSON
  title: string;
  order: number;
  parentId: string | null; // ID of parent section/subsection
}

export interface PrimitiveComponent extends BaseComponent {
  category: ComponentCategory.Primitive;
  type: PrimitiveType;
  placeholder?: string;
  tooltip?: string;
  defaultValue?: any;
  required?: boolean;
  validation?: ValidationRule[];
}

export interface TextComponent extends PrimitiveComponent {
  type: PrimitiveType.Text;
  minLength?: number;
  maxLength?: number;
  pattern?: string;
}

export interface LongTextComponent extends PrimitiveComponent {
  type: PrimitiveType.LongText;
  minLength?: number;
  maxLength?: number;
  rows?: number;
}

export interface NumberComponent extends PrimitiveComponent {
  type: PrimitiveType.Number;
  min?: number;
  max?: number;
  step?: number;
}

export interface DecimalComponent extends PrimitiveComponent {
  type: PrimitiveType.Decimal;
  min?: number;
  max?: number;
  precision?: number;
  step?: number;
}

export interface DateComponent extends PrimitiveComponent {
  type: PrimitiveType.Date;
  min?: string; // ISO date string
  max?: string; // ISO date string
}

export interface RadioComponent extends PrimitiveComponent {
  type: PrimitiveType.Radio;
  options: string[];
}

export interface BooleanComponent extends PrimitiveComponent {
  type: PrimitiveType.Boolean;
}

export interface DropdownComponent extends PrimitiveComponent {
  type: PrimitiveType.Dropdown;
  options: string[];
  multiple?: boolean;
}

export interface ComplexComponent extends BaseComponent {
  category: ComponentCategory.Complex;
  type: ComplexType;
}

export interface ListComponent extends ComplexComponent {
  type: ComplexType.List;
  itemType: DataType;
  minItems?: number;
  maxItems?: number;
}

export interface KeyValueComponent extends ComplexComponent {
  type: ComplexType.KeyValue;
  keyType: DataType;
  valueType: DataType;
}

export interface GridColumn {
  id: string;
  objectName: string;
  title: string;
  dataType: DataType;
}

export interface GridComponent extends ComplexComponent {
  type: ComplexType.Grid;
  columns: GridColumn[];
}

export interface SectionComponent extends BaseComponent {
  category: ComponentCategory.Section;
  type: SectionType;
  components: string[]; // Array of component IDs
  visibilityCondition?: VisibilityCondition | null;
  validation?: ValidationRule[];
}

export type AnyComponent = 
  | TextComponent
  | LongTextComponent
  | NumberComponent
  | DecimalComponent
  | DateComponent
  | RadioComponent
  | BooleanComponent
  | DropdownComponent
  | ListComponent
  | KeyValueComponent
  | GridComponent
  | SectionComponent;
