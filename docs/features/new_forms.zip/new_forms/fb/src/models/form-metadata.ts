import { AnyComponent } from './component-types';
import { ValidationRule } from './validation-rules';

export interface FormMetadata {
  id: string;
  name: string;
  version: string;
  description?: string;
  components: Record<string, AnyComponent>;
  rootSections: string[]; // IDs of top-level sections
  validation?: ValidationRule[];
  createdAt: string;
  updatedAt: string;
}
