import { DataType } from './component-types';

export enum ConditionOperator {
  Equals = 'equals',
  NotEquals = 'notEquals',
  GreaterThan = 'greaterThan',
  LessThan = 'lessThan',
  GreaterThanOrEqual = 'greaterThanOrEqual',
  LessThanOrEqual = 'lessThanOrEqual',
  Contains = 'contains',
  NotContains = 'notContains',
  StartsWith = 'startsWith',
  EndsWith = 'endsWith',
  IsEmpty = 'isEmpty',
  IsNotEmpty = 'isNotEmpty'
}

export enum LogicalOperator {
  And = 'and',
  Or = 'or'
}

export interface BaseCondition {
  targetComponentId: string; // The component ID this condition depends on
}

export interface SimpleCondition extends BaseCondition {
  operator: ConditionOperator;
  value?: any;
  dataType: DataType;
}

export interface ComplexCondition extends BaseCondition {
  logicalOperator: LogicalOperator;
  conditions: VisibilityCondition[];
}

export type VisibilityCondition = SimpleCondition | ComplexCondition;
