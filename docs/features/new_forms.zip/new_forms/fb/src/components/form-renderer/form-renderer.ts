import styles from './form-renderer.css';
import { store, connectStore } from '../../state/store';

export class FormRenderer extends HTMLElement {
  private unsubscribe: (() => void) | null = null;
  
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
  }

  static get observedAttributes() {
    return ['form-name'];
  }

  attributeChangedCallback(name: string, oldValue: string, newValue: string) {
    if (name === 'form-name' && oldValue !== newValue) {
      this.renderForm(newValue);
    }
  }

  connectedCallback() {
    const formName = this.getAttribute('form-name') || 'Default Form';
    
    if (this.shadowRoot) {
      this.shadowRoot.innerHTML = `
        <style>
          ${styles}
        </style>
        <div class="form-renderer">
          <h2>Form: ${formName}</h2>
          <div id="form-content"></div>
        </div>
      `;
      
      // Connect to Redux store to get components
      this.unsubscribe = connectStore(
        this,
        state => state.formMetadata.components,
        components => this.updateFormContent(components)
      );
    }
  }
  
  disconnectedCallback() {
    if (this.unsubscribe) {
      this.unsubscribe();
      this.unsubscribe = null;
    }
  }

  private renderForm(formName: string) {
    if (this.shadowRoot) {
      const formTitle = this.shadowRoot.querySelector('h2');
      if (formTitle) {
        formTitle.textContent = `Form: ${formName}`;
      }
    }
  }
  
  private updateFormContent(components: any[]) {
    if (!this.shadowRoot) return;
    
    const formContent = this.shadowRoot.getElementById('form-content');
    if (!formContent) return;
    
    if (components.length === 0) {
      formContent.innerHTML = '<p>No components added to this form yet.</p>';
      return;
    }
    
    formContent.innerHTML = `
      <form id="rendered-form">
        ${components.map(component => this.renderComponent(component)).join('')}
        <div class="form-actions">
          <button type="submit">Submit</button>
          <button type="reset">Reset</button>
        </div>
      </form>
    `;
    
    // Add form submit handler
    const form = formContent.querySelector('#rendered-form');
    if (form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        alert('Form submitted successfully!');
      });
    }
  }
  
  private renderComponent(component: any): string {
    // Reuse the rendering logic from forms-playground-panel
    const { type, properties, id } = component;
    
    switch (type) {
      case 'text-input':
        return `
          <div class="form-group">
            <label>${properties.label || 'Text Input'}</label>
            <input type="text" name="${id}" placeholder="${properties.placeholder || ''}" ${properties.required ? 'required' : ''}>
          </div>
        `;
      case 'text-area':
        return `
          <div class="form-group">
            <label>${properties.label || 'Text Area'}</label>
            <textarea name="${id}" placeholder="${properties.placeholder || ''}" rows="${properties.rows || 4}" ${properties.required ? 'required' : ''}></textarea>
          </div>
        `;
      case 'select':
        return `
          <div class="form-group">
            <label>${properties.label || 'Select'}</label>
            <select name="${id}" ${properties.required ? 'required' : ''}>
              ${(properties.options || []).map((option: string) => `<option>${option}</option>`).join('')}
            </select>
          </div>
        `;
      case 'checkbox':
        return `
          <div class="form-group checkbox-group">
            <input type="checkbox" id="checkbox-${id}" name="${id}" ${properties.checked ? 'checked' : ''}>
            <label for="checkbox-${id}">${properties.label || 'Checkbox'}</label>
          </div>
        `;
      case 'radio':
        return `
          <div class="form-group">
            <label class="group-label">${properties.label || 'Radio'}</label>
            ${(properties.options || []).map((option: string, index: number) => `
              <div class="radio-option">
                <input type="radio" name="${id}" id="radio-${id}-${index}" 
                  value="${option}" ${option === properties.selectedOption ? 'checked' : ''}>
                <label for="radio-${id}-${index}">${option}</label>
              </div>
            `).join('')}
          </div>
        `;
      default:
        return `<div>Unknown component type: ${type}</div>`;
    }
  }
}

customElements.define('form-renderer', FormRenderer);
