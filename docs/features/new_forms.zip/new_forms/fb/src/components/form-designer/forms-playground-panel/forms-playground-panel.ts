import styles from './forms-playground-panel.css';
import { store, connectStore, FormState } from '../../../state/store';
import { 
  selectComponent, 
  deleteComponent, 
  addComponent
} from '../../../state/actions';
import { 
  AnyComponent, 
  ComponentCategory, 
  SectionType,
  PrimitiveType,
  ComplexType,
  SectionComponent
} from '../../../models/component-types';
import { handleDragStart } from '../../../utils/drag-drop';

// Import our new drop zone components
import '../drop-zones/form-drop-zone';
import '../drop-zones/section-drop-zone';

export class FormsPlaygroundPanel extends HTMLElement {
  private unsubscribe: (() => void) | null = null;
  private components: Record<string, AnyComponent> = {};
  private selectedComponentId: string | null = null;

  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
  }

  connectedCallback() {
    if (this.shadowRoot) {
      this.shadowRoot.innerHTML = `
        <style>
          ${styles}
        </style>
        <h2>Form Playground</h2>
        <div class="playground" id="form-playground">
          <form-drop-zone id="root-container">
            <div id="root-sections"></div>
            <div id="empty-message" class="empty-message">
              <p>Drag components here to build your form</p>
            </div>
          </form-drop-zone>
        </div>
      `;

      // Connect to Redux store
      this.unsubscribe = connectStore(
        this,
        (state: FormState) => ({
          components: state.formMetadata.components,
          rootSections: state.formMetadata.rootSections,
          selectedComponentId: state.selectedComponentId
        }),
        state => {
          this.components = state.components;
          this.selectedComponentId = state.selectedComponentId;
          this.renderFormContent(state.rootSections);
        }
      );
      
      // Set up event listeners for custom events from drop zones
      this.setupDropZoneEvents();
      
      // Store this instance for global access from event handlers
      (window as any).__formPlaygroundPanel = this;
    }
  }

  disconnectedCallback() {
    if (this.unsubscribe) {
      this.unsubscribe();
      this.unsubscribe = null;
    }
    
    // Clean up any event listeners
    this.removeDropZoneEvents();
  }
  
  private setupDropZoneEvents() {
    if (!this.shadowRoot) return;
    
    console.log("Setting up drop zone event listeners");
    
    // Listen for custom events from drop zones
    this.shadowRoot.addEventListener('component-added', (e) => {
      console.log("Caught component-added event in shadow root");
      this.handleComponentAdded(e);
    });
    
    // Add a fallback global listener
    document.addEventListener('component-added-global', (e) => {
      console.log("Caught component-added-global event");
      this.handleComponentAdded(e);
    });
    
    // Keep existing listeners
    this.shadowRoot.addEventListener('section-added', this.handleSectionAdded.bind(this));
    this.shadowRoot.addEventListener('section-moved', this.handleSectionMoved.bind(this));
    this.shadowRoot.addEventListener('component-moved', this.handleComponentMoved.bind(this));
    this.shadowRoot.addEventListener('drop-error', this.handleDropError.bind(this));
  }
  
  private removeDropZoneEvents() {
    if (!this.shadowRoot) return;
    
    // Make sure we're removing the same function references
    this.shadowRoot.removeEventListener('component-added', (e) => {
      this.handleComponentAdded(e);
    });
    document.removeEventListener('component-added-global', (e) => {
      this.handleComponentAdded(e);
    });
    
    this.shadowRoot.removeEventListener('section-added', this.handleSectionAdded.bind(this));
    this.shadowRoot.removeEventListener('section-moved', this.handleSectionMoved.bind(this));
    this.shadowRoot.removeEventListener('component-moved', this.handleComponentMoved.bind(this));
    this.shadowRoot.removeEventListener('drop-error', this.handleDropError.bind(this));
  }
  
  private handleSectionAdded() {
    this.animateLastAddedSection();
  }
  
  private handleSectionMoved(e: Event) {
    const customEvent = e as CustomEvent;
    const sectionId = customEvent.detail?.sectionId;
    if (sectionId) {
      this.animateSectionMove(sectionId);
    }
  }
  
  private handleComponentAdded(e: Event) {
    console.log("handleComponentAdded called with event:", e);
    const customEvent = e as CustomEvent;
    const sectionId = customEvent.detail?.sectionId;
    console.log("Section ID from event:", sectionId);
    
    if (sectionId) {
      this.animateLastAddedComponent(sectionId);
    }
  }
  
  private handleComponentMoved(e: Event) {
    const customEvent = e as CustomEvent;
    const componentId = customEvent.detail?.componentId;
    if (componentId) {
      this.animateComponentMove(componentId);
    }
  }
  
  private handleDropError(e: Event) {
    const customEvent = e as CustomEvent;
    const message = customEvent.detail?.message;
    if (message) {
      alert(message); // For simplicity, still using alert, but could be replaced with a toast
    }
  }
  
  private renderFormContent(rootSectionIds: string[]) {
    if (!this.shadowRoot) return;
    
    const rootSectionsContainer = this.shadowRoot.getElementById('root-sections');
    const emptyMessage = this.shadowRoot.getElementById('empty-message');
    
    if (!rootSectionsContainer || !emptyMessage) return;
    
    // Show/hide empty message
    emptyMessage.style.display = rootSectionIds.length === 0 ? 'flex' : 'none';
    
    // Clear and re-render root sections
    rootSectionsContainer.innerHTML = '';
    
    // Sort root sections by order
    const sortedRootSections = rootSectionIds
      .map((id: string) => this.components[id])
      .filter(Boolean)
      .sort((a: AnyComponent, b: AnyComponent) => a.order - b.order);
    
    // Render each root section
    sortedRootSections.forEach((component: AnyComponent) => {
      const sectionEl = this.renderSection(component);
      rootSectionsContainer.appendChild(sectionEl);
    });
  }
  
  private renderSection(section: AnyComponent): HTMLElement {
    const sectionEl = document.createElement('div');
    sectionEl.className = `section ${section.id === this.selectedComponentId ? 'selected' : ''}`;
    sectionEl.dataset.id = section.id;
    
    // Make the section draggable, but only from the header
    sectionEl.setAttribute('draggable', 'false'); // Section itself shouldn't be draggable
    const sectionHeader = document.createElement('div');
    sectionHeader.className = 'section-header';
    sectionHeader.setAttribute('draggable', 'true'); // Only the header is draggable
    
    sectionHeader.innerHTML = `
      <h3 class="section-title">
        <span class="component-drag-handle">⋮⋮</span>  <!-- Changed from ≡ -->
        ${section.title}
      </h3>
      <div class="section-actions">
        <button class="section-action-btn" data-action="add-section" title="Add Subsection">
          <span class="icon">＋</span>  <!-- Changed from ➕ -->
        </button>
        <button class="section-action-btn" data-action="delete" title="Delete Section">
          <span class="icon">✖</span>  <!-- Changed from 🗑️ -->
        </button>
      </div>
    `;
    
    // Attach drag events specifically to the header
    sectionHeader.addEventListener('dragstart', (e: Event) => {
      if (!(e instanceof DragEvent) || !e.dataTransfer) return;
      e.stopPropagation(); // Prevent bubbling
      
      console.log('Starting section drag for section:', section.id);
      
      handleDragStart(e, {
        id: section.id,
        sourceParentId: section.parentId,
        sourceOrder: section.order
      });
      
      sectionEl.classList.add('dragging');
    });
    
    sectionHeader.addEventListener('dragend', (e: Event) => {
      e.stopPropagation(); // Prevent bubbling
      sectionEl.classList.remove('dragging');
    });
    
    // Create section content separately
    const sectionContent = document.createElement('div');
    sectionContent.className = 'section-content';
    
    sectionContent.innerHTML = `
      <section-drop-zone section-id="${section.id}">
        <!-- Components will be rendered here -->
      </section-drop-zone>
    `;
    
    // Append both parts to the section element
    sectionEl.appendChild(sectionHeader);
    sectionEl.appendChild(sectionContent);
    
    // Attach click event to select this section
    sectionEl.addEventListener('click', (e) => {
      // Don't trigger if clicking a button or child component
      if (
        (e.target as HTMLElement).tagName === 'BUTTON' ||
        (e.target as HTMLElement).closest('.form-component')
      ) {
        return;
      }
      
      store.dispatch(selectComponent(section.id));
      e.stopPropagation();
    });
    
    // Setup action buttons
    const actionButtons = sectionEl.querySelectorAll('.section-action-btn');
    actionButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const action = (btn as HTMLElement).dataset.action;
        
        if (action === 'delete') {
          if (confirm(`Delete section "${section.title}"?`)) {
            store.dispatch(deleteComponent(section.id));
          }
        } else if (action === 'add-section') {
          // Add a subsection if this is a Section (not already a SubSection)
          if (section.type === SectionType.Section) {
            store.dispatch(addComponent(
              SectionType.SubSection, 
              ComponentCategory.Section, 
              section.id
            ));
          }
        }
      });
    });
    
    // Render child components inside the drop zone
    const dropZone = sectionEl.querySelector('section-drop-zone');
    if (dropZone && section.category === ComponentCategory.Section) {
      // We know it's a section component now, safe to cast
      const sectionComponent = section as SectionComponent;
      
      if (Array.isArray(sectionComponent.components)) {
        // Sort components by order
        const childComponents = sectionComponent.components
          .map((id: string) => this.components[id])
          .filter(Boolean)
          .sort((a: AnyComponent, b: AnyComponent) => a.order - b.order);
        
        // Render each component
        childComponents.forEach((component: AnyComponent) => {
          const componentEl = this.renderComponent(component);
          dropZone.appendChild(componentEl);
        });
      }
    }
    
    return sectionEl;
  }
  
  private renderComponent(component: AnyComponent): HTMLElement {
    const componentEl = document.createElement('div');
    componentEl.className = `form-component ${component.category}-component ${component.id === this.selectedComponentId ? 'selected' : ''}`;
    componentEl.dataset.id = component.id;
    componentEl.setAttribute('draggable', 'false');
    
    // Get the appropriate icon for this component type
    const typeIcon = this.getComponentTypeIcon(component);
    
    // Create header with the icon - with special wrapper for animation
    const header = document.createElement('div');
    header.className = 'component-header';
    header.setAttribute('draggable', 'true');
    
    header.innerHTML = `
      <div class="component-left">
        <span class="component-drag-handle">⋮⋮</span>
        <span class="component-type-icon">${typeIcon}</span>
      </div>
      <h4 class="component-title">${component.title}</h4>
      <div class="component-actions">
        <button class="component-action-btn" data-action="delete" title="Delete Component">
          <span class="icon">✖</span>
        </button>
      </div>
    `;
    
    // Append header to component
    componentEl.appendChild(header);
    
    // Setup drag events specifically on the header
    header.addEventListener('dragstart', (e: Event) => {
      if (!(e instanceof DragEvent) || !e.dataTransfer) return;
      e.stopPropagation(); // Prevent event bubbling
      
      console.log('Starting component drag for component:', component.id);
      
      handleDragStart(e, {
        id: component.id,
        sourceParentId: component.parentId,
        sourceOrder: component.order
      });
      
      componentEl.classList.add('dragging');
    });
    
    header.addEventListener('dragend', (e: Event) => {
      e.stopPropagation();
      componentEl.classList.remove('dragging');
    });
    
    // Setup click to select
    componentEl.addEventListener('click', (e) => {
      e.stopPropagation();
      store.dispatch(selectComponent(component.id));
    });
    
    // Setup action buttons - make sure they don't trigger drag events
    const deleteBtn = componentEl.querySelector('[data-action="delete"]');
    if (deleteBtn) {
      deleteBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        if (confirm(`Delete component "${component.title}"?`)) {
          store.dispatch(deleteComponent(component.id));
        }
      });
      
      // Ensure button clicks don't start drag operations
      deleteBtn.addEventListener('mousedown', (e) => {
        e.stopPropagation();
      });
    }
    
    return componentEl;
  }
  
  private getComponentTypeIcon(component: AnyComponent): string {
    switch (component.category) {
      case ComponentCategory.Primitive:
        return this.getPrimitiveComponentIcon(component.type as PrimitiveType);
      case ComponentCategory.Complex:
        return this.getComplexComponentIcon(component.type as ComplexType);
      case ComponentCategory.Section:
        return component.type === SectionType.Section ? '📑' : '📄';
      default:
        return '📋';
    }
  }
  
  private getPrimitiveComponentIcon(type: PrimitiveType): string {
    switch (type) {
      case PrimitiveType.Text: return '🔤';
      case PrimitiveType.LongText: return '📝';
      case PrimitiveType.Number: return '🔢';
      case PrimitiveType.Decimal: return '🔣';
      case PrimitiveType.Date: return '📅';
      case PrimitiveType.Radio: return '🔘';
      case PrimitiveType.Boolean: return '✓';
      case PrimitiveType.Dropdown: return '📝';
      default: return '📋';
    }
  }
  
  private getComplexComponentIcon(type: ComplexType): string {
    switch (type) {
      case ComplexType.List: return '📋';
      case ComplexType.KeyValue: return '🔑';
      case ComplexType.Grid: return '🔲';
      default: return '📋';
    }
  }
  
  private animateLastAddedSection(): void {
    setTimeout(() => {
      if (!this.shadowRoot) return;
      
      const rootSections = this.shadowRoot.querySelector('#root-sections');
      if (!rootSections) return;
      
      const lastSection = rootSections.lastElementChild;
      if (lastSection) {
        lastSection.classList.add('form-component-enter');
        setTimeout(() => {
          lastSection.classList.remove('form-component-enter');
        }, 1200);
      }
    }, 50);
  }
  
  private animateSectionMove(sectionId: string): void {
    setTimeout(() => {
      if (!this.shadowRoot) return;
      
      const sectionEl = this.shadowRoot.querySelector(`[data-id="${sectionId}"]`);
      if (sectionEl) {
        sectionEl.classList.add('form-component-enter');
        setTimeout(() => {
          sectionEl.classList.remove('form-component-enter');
        }, 1200);
      }
    }, 50);
  }
  
  private animateLastAddedComponent(sectionId: string): void {
    console.log("Animating last added component in section:", sectionId);
    
    if (!this.shadowRoot) return;
    
    const dropZone = this.shadowRoot.querySelector(`section-drop-zone[section-id="${sectionId}"]`);
    if (!dropZone) {
      console.log("Drop zone not found");
      return;
    }
    
    const lastComponent = dropZone.lastElementChild;
    if (lastComponent) {
      console.log("Found component to animate:", lastComponent);
      
      // Add animation classes for the whole sequence
      lastComponent.classList.add('form-component-enter', 'new-component');
      
      // Remove animation classes after animation completes
      setTimeout(() => {
        lastComponent.classList.remove('form-component-enter', 'new-component');
      }, 2000); // Increased animation time for the complete sequence
    } else {
      console.log("No component found to animate");
    }
  }
  
  private animateComponentMove(componentId: string): void {
    console.log("Animating moved component:", componentId);
    
    if (!this.shadowRoot) return;
    
    const componentEl = this.shadowRoot.querySelector(`[data-id="${componentId}"]`);
    if (componentEl) {
      console.log("Found moved component:", componentEl);
      
      // Apply the same animation sequence for moved components
      componentEl.classList.add('form-component-enter', 'new-component');
      
      // Remove animation classes after they complete
      setTimeout(() => {
        componentEl.classList.remove('form-component-enter', 'new-component');
      }, 2000); // Match the increased animation time
    } else {
      console.log("Component not found");
    }
  }
  
  // Helper method to animate any component element
  private animateComponentElement(componentEl: HTMLElement): void {
    console.log("Animating component element:", componentEl);
    
    // Apply component animation
    componentEl.classList.add('form-component-enter', 'new-component');
    
    // Remove animation classes after they complete
    setTimeout(() => {
      componentEl.classList.remove('form-component-enter', 'new-component');
    }, 1500);
  }
}

customElements.define('forms-playground-panel', FormsPlaygroundPanel);
