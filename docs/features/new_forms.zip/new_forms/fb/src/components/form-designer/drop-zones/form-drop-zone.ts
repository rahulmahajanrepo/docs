import styles from './drop-zone.css';
import { isSectionDrag, isComponentDrag, getDragData } from '../../../utils/drag-drop';
import { store } from '../../../state/store';
import { addComponent, moveComponent } from '../../../state/actions';
import { ComponentCategory, SectionType } from '../../../models/component-types';

export class FormDropZone extends HTMLElement {
  private dragCounter: number = 0;
  
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
  }
  
  connectedCallback() {
    if (this.shadowRoot) {
      this.shadowRoot.innerHTML = `
        <style>${styles}</style>
        <div class="form-drop-zone">
          <slot></slot>
        </div>
      `;
      
      this.setupDropEvents();
    }
  }
  
  private setupDropEvents() {
    if (!this.shadowRoot) return;
    
    const dropZone = this.shadowRoot.querySelector('.form-drop-zone');
    if (!dropZone) return;
    
    // Switch to regular event handling instead of capture phase
    dropZone.addEventListener('dragenter', this.handleDragEnter.bind(this));
    dropZone.addEventListener('dragover', this.handleDragOver.bind(this));
    dropZone.addEventListener('dragleave', this.handleDragLeave.bind(this));
    dropZone.addEventListener('drop', this.handleDrop.bind(this));
  }
  
  private handleDragEnter(e: Event) {
    if (!(e instanceof DragEvent) || !e.dataTransfer) return;
    
    // Check if we should handle this event
    if (this.isChildSectionDropZoneEvent(e)) {
      return;
    }
    
    e.preventDefault();
    this.dragCounter++;
    
    // Highlight if a section is being dragged - allow any section type
    if (isSectionDrag(e.dataTransfer)) {
      this.setHighlightState(true);
    } else if (isComponentDrag(e.dataTransfer)) {
      // Components can't be dropped directly in the form - show invalid state
      this.setInvalidState(true);
      e.dataTransfer.dropEffect = 'none';
    }
  }
  
  private handleDragOver(e: Event) {
    if (!(e instanceof DragEvent) || !e.dataTransfer) return;
    
    // Check if we should handle this event
    if (this.isChildSectionDropZoneEvent(e)) {
      return;
    }
    
    e.preventDefault();
    
    // Accept any section type for drag over
    if (isSectionDrag(e.dataTransfer)) {
      e.dataTransfer.dropEffect = 'move';
    } else {
      e.dataTransfer.dropEffect = 'none';
    }
  }
  
  private handleDragLeave(e: Event) {
    if (!(e instanceof DragEvent)) return;
    
    // Check if we should handle this event
    if (this.isChildSectionDropZoneEvent(e)) {
      return;
    }
    
    e.preventDefault();
    
    this.dragCounter--;
    
    if (this.dragCounter <= 0) {
      this.dragCounter = 0;
      this.setHighlightState(false);
      this.setInvalidState(false);
    }
  }
  
  private handleDrop(e: Event) {
    if (!(e instanceof DragEvent) || !e.dataTransfer) return;
    
    // Don't handle drops in child section drop zones
    if (this.isChildSectionDropZoneEvent(e)) {
      return;
    }
    
    e.preventDefault();
    e.stopPropagation(); // Ensure no bubbling
    
    console.log("Form drop zone handling drop");
    
    // Reset visual states
    this.setHighlightState(false);
    this.setInvalidState(false);
    this.dragCounter = 0;
    
    const data = getDragData(e.dataTransfer);
    if (!data) {
      console.log("No drag data found");
      return;
    }
    
    console.log("Drop data:", data);
    
    // Handle any section type
    if ((data.componentType && data.category === ComponentCategory.Section) || 
        (data.id && isSectionDrag(e.dataTransfer))) {
      
      // Handle adding a new section
      if (data.componentType) {
        console.log("Adding new section:", data.componentType);
        store.dispatch(addComponent(data.componentType, ComponentCategory.Section));
        
        this.dispatchEvent(new CustomEvent('section-added', {
          bubbles: true,
          composed: true
        }));
      }
      // Handle moving an existing section
      else if (data.id) {
        console.log("Moving existing section:", data.id);
        const state = store.getState();
        const order = Object.values(state.formMetadata.components)
          .filter(c => c.parentId === null && c.category === ComponentCategory.Section)
          .length;
        
        store.dispatch(moveComponent(data.id, null, order));
        
        this.dispatchEvent(new CustomEvent('section-moved', {
          bubbles: true,
          composed: true,
          detail: { sectionId: data.id }
        }));
      }
    } else {
      console.log("Invalid drop - not a section");
      this.showError("Only sections can be dropped here");
    }
  }
  
  // Helper to check if event is happening in a child section drop zone
  private isChildSectionDropZoneEvent(e: Event): boolean {
    // Get the actual target element
    const target = e.target as HTMLElement;
    
    // Check if the target or its parents is a section-drop-zone
    let currentElement = target;
    while (currentElement) {
      if (currentElement.tagName && 
          currentElement.tagName.toLowerCase() === 'section-drop-zone') {
        return true;
      }
      
      if (currentElement === this) {
        // We've reached this element without finding a section-drop-zone
        break;
      }
      
      currentElement = currentElement.parentElement as HTMLElement;
    }
    
    return false;
  }
  
  private setHighlightState(active: boolean) {
    const dropZone = this.shadowRoot?.querySelector('.form-drop-zone');
    if (dropZone) {
      dropZone.classList.toggle('highlight', active);
    }
  }
  
  private setInvalidState(active: boolean) {
    const dropZone = this.shadowRoot?.querySelector('.form-drop-zone');
    if (dropZone) {
      dropZone.classList.toggle('invalid-drop', active);
    }
  }
  
  private showError(message: string) {
    // Use a more subtle notification instead of alert for better UX
    const errorEvent = new CustomEvent('drop-error', {
      bubbles: true,
      composed: true,
      detail: { message }
    });
    this.dispatchEvent(errorEvent);
  }
}

customElements.define('form-drop-zone', FormDropZone);
