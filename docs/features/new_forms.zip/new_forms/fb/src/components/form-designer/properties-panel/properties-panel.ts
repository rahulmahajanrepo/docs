import styles from './properties-panel.css';
import { store, connectStore, FormState } from '../../../state/store';
import { updateComponent, addValidationRule, removeValidationRule, setVisibilityCondition } from '../../../state/actions';
import { 
  AnyComponent,
  ComponentCategory,
  PrimitiveType,
  ComplexType,
  SectionType,
  DataType
} from '../../../models/component-types';
import { ValidationRuleType } from '../../../models/validation-rules';
import { ConditionOperator } from '../../../models/visibility-conditions';
import { objectNameToTitle } from '../../../utils/string-utils';

export class PropertiesPanel extends HTMLElement {
  private unsubscribe: (() => void) | null = null;
  private currentComponent: AnyComponent | null = null;

  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
  }

  connectedCallback() {
    if (this.shadowRoot) {
      this.shadowRoot.innerHTML = `
        <style>
          ${styles}
        </style>
        <h2>Properties</h2>
        <div id="properties-content">
          <div id="no-selection">
            Select a component to edit its properties
          </div>
          <div id="properties-form" style="display: none;"></div>
        </div>
      `;

      // Connect to Redux store
      this.unsubscribe = connectStore(
        this,
        (state: FormState) => {
          if (state.selectedComponentId) {
            return state.formMetadata.components[state.selectedComponentId] || null;
          }
          return null;
        },
        (component: AnyComponent | null) => {
          this.currentComponent = component;
          this.renderProperties();
        }
      );
    }
  }

  disconnectedCallback() {
    if (this.unsubscribe) {
      this.unsubscribe();
      this.unsubscribe = null;
    }
  }

  private renderProperties(): void {
    if (!this.shadowRoot) return;

    const noSelection = this.shadowRoot.getElementById('no-selection');
    const propertiesForm = this.shadowRoot.getElementById('properties-form');
    
    if (!noSelection || !propertiesForm) return;
    
    if (!this.currentComponent) {
      noSelection.style.display = 'block';
      propertiesForm.style.display = 'none';
      return;
    }
    
    // Show properties form and hide no selection message
    noSelection.style.display = 'none';
    propertiesForm.style.display = 'block';
    
    // Generate form fields based on component category and type
    propertiesForm.innerHTML = this.generatePropertiesForm();
    
    // Add event listeners for property changes
    this.attachPropertyChangeListeners(propertiesForm);
    
    // Focus and select the objectName input field
    setTimeout(() => {
      if (this.shadowRoot) {
        const objectNameInput = this.shadowRoot.getElementById('prop-objectName') as HTMLInputElement;
        if (objectNameInput) {
          objectNameInput.focus();
          objectNameInput.select();
        }
      }
    }, 50); // Small delay to ensure DOM is updated
  }
  
  private generatePropertiesForm(): string {
    if (!this.currentComponent) return '';
    
    const { id, category, type, objectName, title } = this.currentComponent;
    
    // Common properties for all components
    let html = `
      <div class="property-group">
        <h3>${category === ComponentCategory.Section ? 'Section' : 'Component'} Properties</h3>
        
        <div class="property-field">
          <label for="prop-title">Title:</label>
          <input type="text" id="prop-title" value="${title}" data-property="title">
        </div>
        
        <div class="property-field">
          <label for="prop-objectName">Object Name (JSON key):</label>
          <input type="text" id="prop-objectName" value="${objectName}" data-property="objectName">
        </div>
      </div>
    `;
    
    // Category-specific properties
    switch (category) {
      case ComponentCategory.Primitive:
        html += this.generatePrimitiveProperties();
        break;
        
      case ComponentCategory.Complex:
        html += this.generateComplexProperties();
        break;
        
      case ComponentCategory.Section:
        html += this.generateSectionProperties();
        break;
    }
    
    // Validation rules (for non-section components)
    if (category !== ComponentCategory.Section) {
      html += this.generateValidationSection();
    }
    
    return html;
  }
  
  private generatePrimitiveProperties(): string {
    if (!this.currentComponent || this.currentComponent.category !== ComponentCategory.Primitive) {
      return '';
    }
    
    const { type } = this.currentComponent;
    let html = `
      <div class="property-group">
        <h3>Component Configuration</h3>
    `;
    
    // Type-specific properties
    switch (type) {
      case PrimitiveType.Text:
        html += `
          <div class="property-field">
            <label for="prop-placeholder">Placeholder:</label>
            <input type="text" id="prop-placeholder" value="${this.getComponentProperty('placeholder', '')}" data-property="placeholder">
          </div>
          <div class="property-field checkbox-field">
            <input type="checkbox" id="prop-required" ${this.getComponentProperty('required', false) ? 'checked' : ''} data-property="required">
            <label for="prop-required">Required</label>
          </div>
          <div class="property-field">
            <label for="prop-minLength">Min Length:</label>
            <input type="number" id="prop-minLength" value="${this.getComponentProperty('minLength', '')}" data-property="minLength" min="0">
          </div>
          <div class="property-field">
            <label for="prop-maxLength">Max Length:</label>
            <input type="number" id="prop-maxLength" value="${this.getComponentProperty('maxLength', '')}" data-property="maxLength" min="0">
          </div>
          <div class="property-field">
            <label for="prop-pattern">Pattern (regex):</label>
            <input type="text" id="prop-pattern" value="${this.getComponentProperty('pattern', '')}" data-property="pattern" placeholder="e.g. [A-Za-z0-9]+">
          </div>
        `;
        break;
        
      case PrimitiveType.LongText:
        html += `
          <div class="property-field">
            <label for="prop-placeholder">Placeholder:</label>
            <input type="text" id="prop-placeholder" value="${this.getComponentProperty('placeholder', '')}" data-property="placeholder">
          </div>
          <div class="property-field checkbox-field">
            <input type="checkbox" id="prop-required" ${this.getComponentProperty('required', false) ? 'checked' : ''} data-property="required">
            <label for="prop-required">Required</label>
          </div>
          <div class="property-field">
            <label for="prop-rows">Rows:</label>
            <input type="number" id="prop-rows" value="${this.getComponentProperty('rows', 4)}" data-property="rows" min="1" max="20">
          </div>
          <div class="property-field">
            <label for="prop-minLength">Min Length:</label>
            <input type="number" id="prop-minLength" value="${this.getComponentProperty('minLength', '')}" data-property="minLength" min="0">
          </div>
          <div class="property-field">
            <label for="prop-maxLength">Max Length:</label>
            <input type="number" id="prop-maxLength" value="${this.getComponentProperty('maxLength', '')}" data-property="maxLength" min="0">
          </div>
        `;
        break;
        
      case PrimitiveType.Number:
        html += `
          <div class="property-field checkbox-field">
            <input type="checkbox" id="prop-required" ${this.getComponentProperty('required', false) ? 'checked' : ''} data-property="required">
            <label for="prop-required">Required</label>
          </div>
          <div class="property-field">
            <label for="prop-min">Min Value:</label>
            <input type="number" id="prop-min" value="${this.getComponentProperty('min', '')}" data-property="min">
          </div>
          <div class="property-field">
            <label for="prop-max">Max Value:</label>
            <input type="number" id="prop-max" value="${this.getComponentProperty('max', '')}" data-property="max">
          </div>
          <div class="property-field">
            <label for="prop-step">Step:</label>
            <input type="number" id="prop-step" value="${this.getComponentProperty('step', 1)}" data-property="step" min="1">
          </div>
        `;
        break;
        
      case PrimitiveType.Decimal:
        html += `
          <div class="property-field checkbox-field">
            <input type="checkbox" id="prop-required" ${this.getComponentProperty('required', false) ? 'checked' : ''} data-property="required">
            <label for="prop-required">Required</label>
          </div>
          <div class="property-field">
            <label for="prop-min">Min Value:</label>
            <input type="number" id="prop-min" value="${this.getComponentProperty('min', '')}" data-property="min" step="0.01">
          </div>
          <div class="property-field">
            <label for="prop-max">Max Value:</label>
            <input type="number" id="prop-max" value="${this.getComponentProperty('max', '')}" data-property="max" step="0.01">
          </div>
          <div class="property-field">
            <label for="prop-precision">Decimal Places:</label>
            <input type="number" id="prop-precision" value="${this.getComponentProperty('precision', 2)}" data-property="precision" min="0" max="10">
          </div>
          <div class="property-field">
            <label for="prop-step">Step:</label>
            <input type="number" id="prop-step" value="${this.getComponentProperty('step', 0.01)}" data-property="step" min="0.01" step="0.01">
          </div>
        `;
        break;
        
      case PrimitiveType.Date:
        html += `
          <div class="property-field checkbox-field">
            <input type="checkbox" id="prop-required" ${this.getComponentProperty('required', false) ? 'checked' : ''} data-property="required">
            <label for="prop-required">Required</label>
          </div>
          <div class="property-field">
            <label for="prop-min">Min Date:</label>
            <input type="date" id="prop-min" value="${this.getComponentProperty('min', '')}" data-property="min">
          </div>
          <div class="property-field">
            <label for="prop-max">Max Date:</label>
            <input type="date" id="prop-max" value="${this.getComponentProperty('max', '')}" data-property="max">
          </div>
        `;
        break;
        
      case PrimitiveType.Radio:
      case PrimitiveType.Dropdown:
        html += `
          <div class="property-field checkbox-field">
            <input type="checkbox" id="prop-required" ${this.getComponentProperty('required', false) ? 'checked' : ''} data-property="required">
            <label for="prop-required">Required</label>
          </div>
          <div class="property-field">
            <label for="prop-options">Options (one per line):</label>
            <textarea id="prop-options" data-property="options">${(this.getComponentProperty('options', []) as string[]).join('\n')}</textarea>
          </div>
        `;
        
        if (type === PrimitiveType.Dropdown) {
          html += `
            <div class="property-field checkbox-field">
              <input type="checkbox" id="prop-multiple" ${this.getComponentProperty('multiple', false) ? 'checked' : ''} data-property="multiple">
              <label for="prop-multiple">Allow Multiple Selection</label>
            </div>
          `;
        }
        break;
        
      case PrimitiveType.Boolean:
        html += `
          <div class="property-field checkbox-field">
            <input type="checkbox" id="prop-defaultChecked" ${this.getComponentProperty('checked', false) ? 'checked' : ''} data-property="checked">
            <label for="prop-defaultChecked">Default Checked</label>
          </div>
        `;
        break;
    }
    
    html += `</div>`;
    return html;
  }
  
  private generateComplexProperties(): string {
    if (!this.currentComponent || this.currentComponent.category !== ComponentCategory.Complex) {
      return '';
    }
    
    const { type } = this.currentComponent;
    let html = `
      <div class="property-group">
        <h3>Component Configuration</h3>
    `;
    
    // Type-specific properties
    switch (type) {
      case ComplexType.List:
        html += `
          <div class="property-field">
            <label for="prop-itemType">Item Type:</label>
            <select id="prop-itemType" data-property="itemType">
              ${this.generateDataTypeOptions(this.getComponentProperty('itemType', DataType.String))}
            </select>
          </div>
          <div class="property-field">
            <label for="prop-minItems">Min Items:</label>
            <input type="number" id="prop-minItems" value="${this.getComponentProperty('minItems', '')}" data-property="minItems" min="0">
          </div>
          <div class="property-field">
            <label for="prop-maxItems">Max Items:</label>
            <input type="number" id="prop-maxItems" value="${this.getComponentProperty('maxItems', '')}" data-property="maxItems" min="0">
          </div>
        `;
        break;
        
      case ComplexType.KeyValue:
        html += `
          <div class="property-field">
            <label for="prop-keyType">Key Type:</label>
            <select id="prop-keyType" data-property="keyType">
              ${this.generateDataTypeOptions(this.getComponentProperty('keyType', DataType.String))}
            </select>
          </div>
          <div class="property-field">
            <label for="prop-valueType">Value Type:</label>
            <select id="prop-valueType" data-property="valueType">
              ${this.generateDataTypeOptions(this.getComponentProperty('valueType', DataType.String))}
            </select>
          </div>
        `;
        break;
        
      case ComplexType.Grid:
        html += `
          <div class="property-field">
            <label>Grid Columns:</label>
            <div id="grid-columns">
              <p>Column editing will be implemented in a future update</p>
            </div>
          </div>
        `;
        break;
    }
    
    html += `</div>`;
    return html;
  }
  
  private generateSectionProperties(): string {
    if (!this.currentComponent || this.currentComponent.category !== ComponentCategory.Section) {
      return '';
    }
    
    const { type } = this.currentComponent;
    
    let html = `
      <div class="property-group">
        <h3>Section Configuration</h3>
        
        <div class="property-field">
          <label>Section Type:</label>
          <div>${type}</div>
        </div>
      </div>
    `;
    
    // Visibility conditions (only for sections)
    html += `
      <div class="section-title">Visibility Conditions</div>
      <div class="property-group">
        <p>Define when this section should be visible</p>
        <div id="visibility-conditions">
          <p>No visibility conditions defined</p>
        </div>
        <button class="add-condition-btn">Add Condition</button>
      </div>
    `;
    
    return html;
  }
  
  private generateValidationSection(): string {
    return `
      <div class="section-title">Validation Rules</div>
      <div class="property-group">
        <div id="validation-rules">
          <p>No validation rules defined</p>
        </div>
        <button class="add-condition-btn" id="add-validation-rule">Add Validation Rule</button>
      </div>
    `;
  }
  
  private generateDataTypeOptions(selectedValue: string): string {
    const options = [
      { value: DataType.String, label: 'Text' },
      { value: DataType.Number, label: 'Number' },
      { value: DataType.Boolean, label: 'Boolean' },
      { value: DataType.Date, label: 'Date' },
      { value: DataType.Object, label: 'Object' },
      { value: DataType.Array, label: 'Array' }
    ];
    
    return options.map(option => 
      `<option value="${option.value}" ${option.value === selectedValue ? 'selected' : ''}>${option.label}</option>`
    ).join('');
  }
  
  private getComponentProperty(property: string, defaultValue: any): any {
    if (!this.currentComponent) return defaultValue;
    
    return (this.currentComponent as any)[property] !== undefined 
      ? (this.currentComponent as any)[property] 
      : defaultValue;
  }
  
  private attachPropertyChangeListeners(formElement: HTMLElement): void {
    if (!this.currentComponent) return;
    
    const inputs = formElement.querySelectorAll('input, textarea, select');
    
    inputs.forEach(input => {
      input.addEventListener('change', (e) => {
        const target = e.target as HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement;
        const property = target.dataset.property;
        
        if (!property || !this.currentComponent) return;
        
        const updates: Record<string, any> = {};
        
        // Handle different input types
        if (target instanceof HTMLInputElement && target.type === 'checkbox') {
          updates[property] = target.checked;
        } else if (property === 'options' && target instanceof HTMLTextAreaElement) {
          // Split textarea content by line for options
          updates[property] = target.value
            .split('\n')
            .map(line => line.trim())
            .filter(line => line !== '');
        } else if (target instanceof HTMLInputElement && target.type === 'number') {
          // Handle empty number inputs
          updates[property] = target.value === '' ? undefined : Number(target.value);
        } else {
          updates[property] = target.value;
          
          // If objectName is being updated, automatically update the title as well
          if (property === 'objectName' && target.value) {
            const titleInput = formElement.querySelector('#prop-title') as HTMLInputElement;
            
            // Only update title if it hasn't been manually edited or if it was the default generated title
            if (titleInput && 
               (titleInput.value === this.getComponentProperty('title', '') || 
                this.isDefaultGeneratedTitle(titleInput.value))) {
              const newTitle = objectNameToTitle(target.value);
              titleInput.value = newTitle;
              updates['title'] = newTitle;
            }
          }
        }
        
        // Dispatch the update
        store.dispatch(updateComponent(this.currentComponent.id, updates));
      });
    });
    
    // Handle add validation rule button
    const addValidationBtn = formElement.querySelector('#add-validation-rule');
    if (addValidationBtn && this.currentComponent) {
      addValidationBtn.addEventListener('click', () => {
        // Add a simple required rule as example
        store.dispatch(addValidationRule(
          this.currentComponent!.id,
          {
            type: ValidationRuleType.Required,
            message: 'This field is required'
          }
        ));
      });
    }
    
    // Handle add visibility condition button
    const addConditionBtn = formElement.querySelector('.add-condition-btn');
    if (addConditionBtn && this.currentComponent.category === ComponentCategory.Section) {
      addConditionBtn.addEventListener('click', () => {
        alert('Visibility condition editor will be implemented in a future update');
        
        // Example for how it would work
        /* 
        store.dispatch(setVisibilityCondition(
          this.currentComponent!.id,
          {
            targetComponentId: 'some-component-id',
            operator: ConditionOperator.Equals,
            value: 'some-value',
            dataType: DataType.String
          }
        ));
        */
      });
    }
  }

  // Helper to determine if a title is likely a default generated one
  private isDefaultGeneratedTitle(title: string): boolean {
    // Check if title matches pattern like "New text" or "New Section"
    return /^New\s[a-zA-Z]+$/.test(title);
  }
}

customElements.define('properties-panel', PropertiesPanel);
