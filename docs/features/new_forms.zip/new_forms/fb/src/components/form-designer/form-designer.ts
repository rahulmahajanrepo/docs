import Split from 'split.js';
import styles from './form-designer.css';
import './component-selection-panel/component-selection-panel';
import './forms-playground-panel/forms-playground-panel';
import './properties-panel/properties-panel';
import { store } from '../../state/store';
import { buildDependencyDAG } from '../../utils/dag';

export class FormDesigner extends HTMLElement {
  private splitInstance: any = null;
  private metadataModal: HTMLElement | null = null;
  private dagModal: HTMLElement | null = null;

  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
  }

  connectedCallback() {
    if (this.shadowRoot) {
      this.shadowRoot.innerHTML = `
        <style>
          ${styles}
        </style>
        <div class="header">
          <button id="export-metadata" class="header-button" data-tooltip="Export Metadata">
            <span class="icon">⤓</span>
          </button>
          <button id="view-dag" class="header-button" data-tooltip="View Dependencies">
            <span class="icon">⚙</span>
          </button>
        </div>
        <div class="container">
          <div class="panel" id="component-panel">
            <component-selection-panel></component-selection-panel>
          </div>
          <div class="panel" id="playground-panel">
            <forms-playground-panel></forms-playground-panel>
          </div>
          <div class="panel" id="properties-panel">
            <properties-panel></properties-panel>
          </div>
        </div>
      `;

      // Setup split panels
      setTimeout(() => this.initSplitPanels(), 0);
      
      // Setup button event listeners with ripple effect
      this.setupButtonListeners();
    }
  }

  disconnectedCallback() {
    if (this.splitInstance) {
      this.splitInstance.destroy();
    }
    
    this.closeModals();
  }

  private initSplitPanels() {
    if (this.shadowRoot) {
      const panels = Array.from(this.shadowRoot.querySelectorAll('.panel'));
      
      if (panels.length === 3) {
        this.splitInstance = Split(panels as HTMLElement[], {
          sizes: [20, 60, 20],
          minSize: 100,
          gutterSize: 10,
          direction: 'horizontal'
        });
      }
    }
  }
  
  private setupButtonListeners() {
    if (!this.shadowRoot) return;
    
    const exportMetadataBtn = this.shadowRoot.getElementById('export-metadata');
    const viewDagBtn = this.shadowRoot.getElementById('view-dag');
    
    if (exportMetadataBtn) {
      exportMetadataBtn.addEventListener('click', (e) => {
        this.addRippleEffect(e);
        this.showMetadataModal();
      });
    }
    
    if (viewDagBtn) {
      viewDagBtn.addEventListener('click', (e) => {
        this.addRippleEffect(e);
        this.showDagModal();
      });
    }
  }

  private addRippleEffect(e: MouseEvent) {
    const button = e.currentTarget as HTMLElement;
    const ripple = document.createElement('span');
    ripple.className = 'ripple';
    button.appendChild(ripple);
    
    // Remove after animation completes
    setTimeout(() => {
      ripple.remove();
    }, 600);
  }
  
  private showMetadataModal() {
    // Get current form metadata from store
    const state = store.getState();
    const formMetadata = state.formMetadata;
    
    // Create modal if it doesn't exist
    if (!this.metadataModal) {
      this.metadataModal = document.createElement('div');
      this.metadataModal.className = 'modal-overlay';
      this.metadataModal.innerHTML = `
        <div class="modal">
          <div class="modal-header">
            <h3 class="modal-title">Form Metadata</h3>
            <button class="modal-close">&times;</button>
          </div>
          <div class="modal-content">
            <div class="json-viewer"></div>
          </div>
        </div>
      `;
      
      // Setup close button
      const closeBtn = this.metadataModal.querySelector('.modal-close');
      if (closeBtn) {
        closeBtn.addEventListener('click', () => {
          this.closeModals();
        });
      }
      
      // Close when clicking outside the modal
      this.metadataModal.addEventListener('click', (event) => {
        if (event.target === this.metadataModal) {
          this.closeModals();
        }
      });
    }
    
    // Update content
    const jsonViewer = this.metadataModal.querySelector('.json-viewer');
    if (jsonViewer) {
      jsonViewer.textContent = JSON.stringify(formMetadata, null, 2);
    }
    
    // Append to shadow DOM
    if (this.shadowRoot && !this.metadataModal.parentNode) {
      this.shadowRoot.appendChild(this.metadataModal);
    }
  }
  
  private showDagModal() {
    // Get current components from store
    const state = store.getState();
    const { components } = state.formMetadata;
    
    // Build the DAG
    const dag = buildDependencyDAG(components);
    
    // Create modal if it doesn't exist
    if (!this.dagModal) {
      this.dagModal = document.createElement('div');
      this.dagModal.className = 'modal-overlay';
      this.dagModal.innerHTML = `
        <div class="modal">
          <div class="modal-header">
            <h3 class="modal-title">Dependency Graph</h3>
            <button class="modal-close">&times;</button>
          </div>
          <div class="modal-content">
            <div class="dag-viewer">
              <p>Dependency graph visualization will be rendered here.</p>
              <div class="json-viewer"></div>
            </div>
          </div>
        </div>
      `;
      
      // Setup close button
      const closeBtn = this.dagModal.querySelector('.modal-close');
      if (closeBtn) {
        closeBtn.addEventListener('click', () => {
          this.closeModals();
        });
      }
      
      // Close when clicking outside the modal
      this.dagModal.addEventListener('click', (event) => {
        if (event.target === this.dagModal) {
          this.closeModals();
        }
      });
    }
    
    // Update content
    const jsonViewer = this.dagModal.querySelector('.json-viewer');
    if (jsonViewer) {
      jsonViewer.textContent = JSON.stringify(dag, null, 2);
    }
    
    // Append to shadow DOM
    if (this.shadowRoot && !this.dagModal.parentNode) {
      this.shadowRoot.appendChild(this.dagModal);
    }
  }
  
  private closeModals() {
    if (this.shadowRoot) {
      if (this.metadataModal && this.metadataModal.parentNode) {
        this.shadowRoot.removeChild(this.metadataModal);
      }
      
      if (this.dagModal && this.dagModal.parentNode) {
        this.shadowRoot.removeChild(this.dagModal);
      }
    }
  }
}

customElements.define('form-designer', FormDesigner);
