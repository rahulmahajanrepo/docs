import styles from './drop-zone.css';
import { isSectionDrag, isComponentDrag, getDragData, isDropAllowed } from '../../../utils/drag-drop';
import { store } from '../../../state/store';
import { addComponent, moveComponent } from '../../../state/actions';
import { ComponentCategory, SectionType } from '../../../models/component-types';

export class SectionDropZone extends HTMLElement {
  private sectionId: string | null = null;
  private dragCounter: number = 0;
  
  // Define the observed attributes
  static get observedAttributes() {
    return ['section-id'];
  }
  
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
  }
  
  connectedCallback() {
    if (this.shadowRoot) {
      this.shadowRoot.innerHTML = `
        <style>${styles}</style>
        <div class="section-drop-zone">
          <slot></slot>
        </div>
      `;
      
      // Get section ID
      this.sectionId = this.getAttribute('section-id');
      
      // Setup event listeners
      this.setupDropEvents();
    }
  }
  
  attributeChangedCallback(name: string, oldValue: string, newValue: string) {
    if (name === 'section-id' && oldValue !== newValue) {
      this.sectionId = newValue;
    }
  }
  
  disconnectedCallback() {
    // Clean up if needed
  }
  
  private setupDropEvents() {
    if (!this.shadowRoot) return;
    
    const dropZone = this.shadowRoot.querySelector('.section-drop-zone');
    if (!dropZone) return;
    
    dropZone.addEventListener('dragenter', this.handleDragEnter.bind(this));
    dropZone.addEventListener('dragover', this.handleDragOver.bind(this));
    dropZone.addEventListener('dragleave', this.handleDragLeave.bind(this));
    dropZone.addEventListener('drop', this.handleDrop.bind(this));
  }
  
  private handleDragEnter(e: Event) {
    if (!(e instanceof DragEvent) || !e.dataTransfer) return;
    e.preventDefault();
    e.stopPropagation(); // Prevent bubbling to parent
    
    this.dragCounter++;
    
    // Accept components or subsections, but not regular sections
    if (this.canAcceptDragItem(e.dataTransfer)) {
      this.setHighlightState(true);
    } else {
      // Show invalid state for items that can't be dropped here
      this.setInvalidState(true);
      e.dataTransfer.dropEffect = 'none';
    }
  }
  
  private handleDragOver(e: Event) {
    if (!(e instanceof DragEvent) || !e.dataTransfer) return;
    e.preventDefault();
    e.stopPropagation(); // Prevent bubbling to parent
    
    // Set appropriate drop effect based on what's being dragged
    if (this.canAcceptDragItem(e.dataTransfer)) {
      e.dataTransfer.dropEffect = 'move';
    } else {
      e.dataTransfer.dropEffect = 'none';
    }
  }
  
  private handleDragLeave(e: Event) {
    if (!(e instanceof DragEvent)) return;
    e.preventDefault();
    e.stopPropagation(); // Prevent bubbling to parent
    
    this.dragCounter--;
    
    if (this.dragCounter <= 0) {
      this.dragCounter = 0; // Ensure it doesn't go negative
      this.setHighlightState(false);
      this.setInvalidState(false);
    }
  }
  
  private handleDrop(e: Event) {
    if (!(e instanceof DragEvent) || !e.dataTransfer || !this.sectionId) return;
    e.preventDefault();
    e.stopPropagation(); // Prevent event bubbling completely
    
    console.log("Section drop zone handling drop");
    
    // Reset visual states
    this.setHighlightState(false);
    this.setInvalidState(false);
    this.dragCounter = 0;
    
    const data = getDragData(e.dataTransfer);
    if (!data) return;
    
    // Log data to debug issues
    console.log("Drop data:", data);
    
    // If we're dropping a regular section, show error
    if (isSectionDrag(e.dataTransfer) && this.isRegularSection(data)) {
      this.showError("Sections cannot be dropped inside other sections");
      return;
    }
    
    // Allow primitive components, complex components and subsections
    // Check for circular references only for section types
    if (data.id) {
      const state = store.getState();
      const component = state.formMetadata.components[data.id];
      
      // If this is a section component, check if it's allowed to drop
      if (component?.category === ComponentCategory.Section) {
        if (!isDropAllowed(data, this.sectionId)) {
          this.showError("Cannot drop here: would create a circular reference");
          return;
        }
      }
    }
    
    // Handle new component or subsection drop
    if (data.componentType && data.category !== undefined) {
      store.dispatch(addComponent(data.componentType, data.category, this.sectionId));
      
      console.log("Component added - dispatching event for section:", this.sectionId);
      
      // Dispatch event with improved visibility and logging
      try {
        const event = new CustomEvent('component-added', { 
          bubbles: true, 
          composed: true, 
          detail: { sectionId: this.sectionId } 
        });
        
        this.dispatchEvent(event);
        console.log("Event dispatched successfully");
        
        // Add a direct global dispatch as backup
        document.dispatchEvent(new CustomEvent('component-added-global', {
          detail: { sectionId: this.sectionId }
        }));
      } catch(err) {
        console.error("Error dispatching component-added event:", err);
      }
    }
    // Handle moving existing component
    else if (data.id) {
      const state = store.getState();
      const component = state.formMetadata.components[data.id];
      
      if (!component) return;
      
      // Don't allow regular sections to be dropped in other sections
      if (component.category === ComponentCategory.Section && 
          component.type === SectionType.Section) {
        this.showError("Sections cannot be dropped inside other sections");
        return;
      }
      
      const newOrder = Object.values(state.formMetadata.components)
        .filter(c => c.parentId === this.sectionId)
        .length;
      
      store.dispatch(moveComponent(data.id, this.sectionId, newOrder));
      
      console.log("Component moved - dispatching event for component:", data.id);
      // Dispatch custom event for animation
      this.dispatchEvent(new CustomEvent('component-moved', { 
        bubbles: true, 
        composed: true,
        detail: { componentId: data.id } 
      }));
    }
  }
  
  // Helper to check if the item being dragged can be accepted
  private canAcceptDragItem(dataTransfer: DataTransfer): boolean {
    // Accept any primitive or complex component
    if (isComponentDrag(dataTransfer)) {
      return true;
    }
    
    // Accept subsections but not regular sections
    if (isSectionDrag(dataTransfer)) {
      const data = getDragData(dataTransfer);
      if (!data) return false;
      
      // If it's a new component
      if (data.componentType) {
        return data.category === ComponentCategory.Section && 
               data.componentType === SectionType.SubSection;
      }
      
      // If it's an existing component
      if (data.id) {
        const state = store.getState();
        const component = state.formMetadata.components[data.id];
        return component?.category === ComponentCategory.Section && 
               component?.type === SectionType.SubSection;
      }
    }
    
    return false;
  }
  
  // Helper to check if the item is a regular section (not a subsection)
  private isRegularSection(data: any): boolean {
    // If it's a new component
    if (data.componentType) {
      return data.category === ComponentCategory.Section && 
             data.componentType === SectionType.Section;
    }
    
    // If it's an existing component
    if (data.id) {
      const state = store.getState();
      const component = state.formMetadata.components[data.id];
      return component?.category === ComponentCategory.Section && 
             component?.type === SectionType.Section;
    }
    
    return false;
  }
  
  private setHighlightState(active: boolean) {
    const dropZone = this.shadowRoot?.querySelector('.section-drop-zone');
    if (dropZone) {
      dropZone.classList.toggle('highlight', active);
    }
  }
  
  private setInvalidState(active: boolean) {
    const dropZone = this.shadowRoot?.querySelector('.section-drop-zone');
    if (dropZone) {
      dropZone.classList.toggle('invalid-drop', active);
    }
  }
  
  private showError(message: string) {
    // Use a more subtle notification instead of alert for better UX
    const errorEvent = new CustomEvent('drop-error', {
      bubbles: true,
      composed: true,
      detail: { message }
    });
    this.dispatchEvent(errorEvent);
  }
}

customElements.define('section-drop-zone', SectionDropZone);
