import styles from './component-selection-panel.css';
import { 
  ComponentCategory, 
  PrimitiveType, 
  ComplexType, 
  SectionType 
} from '../../../models/component-types';
import { handleDragStart } from '../../../utils/drag-drop';

export class ComponentSelectionPanel extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
  }

  connectedCallback() {
    if (this.shadowRoot) {
      this.shadowRoot.innerHTML = `
        <style>
          ${styles}
        </style>
        <h2>Components</h2>
        
        <div class="category-title">Primitive Components</div>
        <div class="component-list" id="primitive-components">
          ${this.renderPrimitiveComponents()}
        </div>
        
        <div class="category-title">Complex Components</div>
        <div class="component-list" id="complex-components">
          ${this.renderComplexComponents()}
        </div>
        
        <div class="category-title">Section Components</div>
        <div class="component-list" id="section-components">
          ${this.renderSectionComponents()}
        </div>
      `;
      
      this.setupDragEvents();
    }
  }

  private renderPrimitiveComponents(): string {
    const primitiveComponents = [
      { type: PrimitiveType.Text, name: 'Text', icon: '🔤' },
      { type: PrimitiveType.LongText, name: 'Long Text', icon: '📋' },
      { type: PrimitiveType.Number, name: 'Number', icon: '🔢' },
      { type: PrimitiveType.Decimal, name: 'Decimal', icon: '🔣' },
      { type: PrimitiveType.Date, name: 'Date', icon: '📅' },
      { type: PrimitiveType.Radio, name: 'Radio', icon: '🔘' },
      { type: PrimitiveType.Boolean, name: 'Boolean', icon: '✓' },
      { type: PrimitiveType.Dropdown, name: 'Dropdown', icon: '📝' }
    ];
    
    return primitiveComponents.map(comp => `
      <div class="component-item primitive-component" 
           data-type="${comp.type}" 
           data-category="${ComponentCategory.Primitive}" 
           draggable="true">
        <span class="icon">${comp.icon}</span>
        ${comp.name}
      </div>
    `).join('');
  }
  
  private renderComplexComponents(): string {
    const complexComponents = [
      { type: ComplexType.List, name: 'List', icon: '📋' },
      { type: ComplexType.KeyValue, name: 'Key-Value Pairs', icon: '🔑' },
      { type: ComplexType.Grid, name: 'Grid', icon: '🔲' }
    ];
    
    return complexComponents.map(comp => `
      <div class="component-item complex-component" 
           data-type="${comp.type}" 
           data-category="${ComponentCategory.Complex}" 
           draggable="true">
        <span class="icon">${comp.icon}</span>
        ${comp.name}
      </div>
    `).join('');
  }
  
  private renderSectionComponents(): string {
    const sectionComponents = [
      { type: SectionType.Section, name: 'Section', icon: '📑' },
      { type: SectionType.SubSection, name: 'Sub-Section', icon: '📄' }
    ];
    
    return sectionComponents.map(comp => `
      <div class="component-item section-component" 
           data-type="${comp.type}" 
           data-category="${ComponentCategory.Section}" 
           draggable="true">
        <span class="icon">${comp.icon}</span>
        ${comp.name}
      </div>
    `).join('');
  }
  
  private setupDragEvents(): void {
    if (!this.shadowRoot) return;
    
    const componentItems = this.shadowRoot.querySelectorAll('.component-item');
    
    componentItems.forEach(item => {
      item.addEventListener('dragstart', (event) => {
        const target = event.target as HTMLElement;
        const componentType = target.dataset.type;
        const category = target.dataset.category as ComponentCategory;
        
        if (componentType && category && event instanceof DragEvent) {
          // Mark element as being dragged for styling
          target.classList.add('dragging');
          
          // Set drag data
          handleDragStart(event, {
            componentType,
            category: category as ComponentCategory
          });

          // Add ripple effect on drag start
          if (target instanceof HTMLElement && event instanceof DragEvent) {
            this.addRippleEffect(target, event);
          }
        }
      });

      // Add touch feedback
      item.addEventListener('mousedown', (event: Event) => {
        const mouseEvent = event as MouseEvent;
        if (mouseEvent.target instanceof Element) {
          const componentItem = mouseEvent.target.closest('.component-item');
          if (componentItem instanceof HTMLElement) {
            this.addRippleEffect(componentItem, mouseEvent);
          }
        }
      });
      
      item.addEventListener('dragend', (event) => {
        const target = event.target as HTMLElement;
        target.classList.remove('dragging');
      });
    });
  }

  // Add ripple effect for better visual feedback
  private addRippleEffect(element: HTMLElement | null, event: MouseEvent | DragEvent): void {
    if (!element) return;
    
    const ripple = document.createElement('div');
    ripple.className = 'ripple';
    
    // Position the ripple where cursor clicked
    const rect = element.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    
    ripple.style.width = ripple.style.height = `${size}px`;
    ripple.style.left = `${event.clientX - rect.left - size/2}px`;
    ripple.style.top = `${event.clientY - rect.top - size/2}px`;
    
    // Add to element
    element.appendChild(ripple);
    
    // Remove after animation completes
    setTimeout(() => {
      ripple.remove();
    }, 600);
  }
}

customElements.define('component-selection-panel', ComponentSelectionPanel);
