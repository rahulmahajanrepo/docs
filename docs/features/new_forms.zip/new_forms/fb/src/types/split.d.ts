declare module 'split.js' {
  interface SplitOptions {
    sizes?: number[];
    minSize?: number | number[];
    gutterSize?: number;
    gutterAlign?: string;
    snapOffset?: number;
    dragInterval?: number;
    direction?: 'horizontal' | 'vertical';
    cursor?: string;
    gutter?: (index: number, direction: string) => HTMLElement;
    elementStyle?: (dimension: string, size: string, gutterSize: string, index: number) => object;
    gutterStyle?: (dimension: string, gutterSize: string, index: number) => object;
    onDrag?: (sizes: number[]) => void;
    onDragStart?: (sizes: number[]) => void;
    onDragEnd?: (sizes: number[]) => void;
  }

  function Split(
    elements: string | HTMLElement[] | NodeListOf<HTMLElement>,
    options?: SplitOptions
  ): {
    setSizes: (sizes: number[]) => void;
    getSizes: () => number[];
    collapse: (index: number) => void;
    destroy: (preserveStyles?: boolean, preserveGutters?: boolean) => void;
  };

  export = Split;
}
