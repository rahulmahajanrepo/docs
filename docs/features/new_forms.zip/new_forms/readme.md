# Commands to run projects
form-builder:
cd form-builder
npm run build

react-app:
npm install
npm start